import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";

dotenv.config();

// Lazy-loaded Supabase client helper
let supabaseClient: any = null;

function getSupabaseClient() {
  if (!supabaseClient) {
    const supabaseUrl = process.env.SUPABASE_URL || "https://bdccnjcttfnthldxvirx.supabase.co";
    const supabaseKey = process.env.SUPABASE_KEY || "sb_publishable_Qs0sRrSAKZ1dksXu0QbWrw_MFtPMcH4";
    supabaseClient = createClient(supabaseUrl, supabaseKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
  }
  return supabaseClient;
}

// Lazy-loaded GoogleGenAI client helper
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not defined in Settings > Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Parse JSON bodies
  app.use(express.json());

  // API Endpoints
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // Supabase Auth & Sync Endpoints
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { email, password, profileName, profileClass, profileBoard } = req.body;
      const client = getSupabaseClient();

      const { data, error } = await client.auth.signUp({
        email,
        password,
        options: {
          data: {
            profileName: profileName || "Aryan Sharma",
            profileClass: profileClass || "Class 8",
            profileBoard: profileBoard || "CBSE",
            subjectsData: [],
            completedDates: [],
            quizHistory: [],
            savedNotes: [],
            updated_at: new Date().toISOString()
          }
        }
      });

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.json({ success: true, user: data.user, session: data.session });
    } catch (error: any) {
      console.error("Supabase Signup error:", error);
      res.status(500).json({ error: error.message || "An error occurred during signup" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const client = getSupabaseClient();

      const { data, error } = await client.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.json({ success: true, user: data.user, session: data.session });
    } catch (error: any) {
      console.error("Supabase Login error:", error);
      res.status(500).json({ error: error.message || "An error occurred during login" });
    }
  });

  app.post("/api/auth/sync", async (req, res) => {
    try {
      const { token, profileName, profileClass, profileBoard, subjectsData, completedDates, quizHistory, savedNotes } = req.body;
      if (!token) {
        return res.status(401).json({ error: "No session token provided" });
      }

      const client = getSupabaseClient();
      
      const { error: sessionError } = await client.auth.setSession({
        access_token: token,
        refresh_token: token
      });

      if (sessionError) {
        return res.status(401).json({ error: "Invalid session token: " + sessionError.message });
      }

      const { data, error } = await client.auth.updateUser({
        data: {
          profileName,
          profileClass,
          profileBoard,
          subjectsData,
          completedDates,
          quizHistory,
          savedNotes,
          updated_at: new Date().toISOString()
        }
      });

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.json({ success: true, user: data.user });
    } catch (error: any) {
      console.error("Supabase Sync error:", error);
      res.status(500).json({ error: error.message || "An error occurred during sync" });
    }
  });

  // AI Tutor chat route
  app.post("/api/tutor/chat", async (req, res) => {
    try {
      const { message, history, contextSubject } = req.body;
      const client = getGeminiClient();

      const systemInstruction = `You are DyanSetu AI, a premium, warm, encouraging, and highly knowledgeable 1-on-1 personalized AI study tutor for K-12 students (currently targeting Class 8, CBSE syllabus, but adaptable). 
      Your tone should be engaging, supportive, clear, and simple without being condescending.
      Explain complex concepts using clever metaphors, real-world analogies, and step-by-step logic.
      Whenever a student is confused, encourage them! Use bullet points or small paragraphs to keep information highly readable.
      The student is Aryan Sharma.
      ${contextSubject ? `The current active subject is: ${contextSubject}.` : ""}
      Answer the user's queries directly, concisely, and with premium pedagogical craftsmanship. Limit your response to at most 3-4 concise paragraphs unless they ask for a deep explanation.`;

      const contents = [];
      
      // Convert history to format expected by generateContent or use chats
      if (history && Array.isArray(history)) {
        for (const turn of history) {
          contents.push({
            role: turn.role,
            parts: [{ text: turn.text }]
          });
        }
      }
      contents.push({
        role: "user",
        parts: [{ text: message }]
      });

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("AI Tutor chat error:", error);
      res.status(500).json({ error: error.message || "An error occurred with the AI Tutor" });
    }
  });

  // AI Structured Quiz Generator
  app.post("/api/tutor/generate-quiz", async (req, res) => {
    try {
      const { subject, topic } = req.body;
      const client = getGeminiClient();

      const prompt = `Create a high-quality 5-question multiple-choice quiz about ${subject}${topic ? ` specifically focusing on "${topic}"` : ""}. 
      The questions must be highly educational, calibrated for a Class 8 student, and cover core conceptual areas.
      Ensure the incorrect options are realistic common misconceptions, and the explanations are extremely detailed and encouraging.`;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are an elite quiz curator. Output a strictly compliant JSON matching the provided schema.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: "Friendly title of the quiz, e.g. 'Advanced Algebra Challenge'" },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.INTEGER, description: "Question index (1 to 5)" },
                    question: { type: Type.STRING, description: "The conceptual multiple choice question" },
                    options: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                      description: "Exactly 4 options"
                    },
                    correctOptionIndex: { type: Type.INTEGER, description: "The correct option index (0 to 3)" },
                    explanation: { type: Type.STRING, description: "Detailed explanation of why the correct answer is right and why other options are common traps, written in an encouraging voice." }
                  },
                  required: ["id", "question", "options", "correctOptionIndex", "explanation"]
                }
              }
            },
            required: ["title", "questions"]
          }
        }
      });

      const quizData = JSON.parse(response.text || "{}");
      res.json(quizData);
    } catch (error: any) {
      console.error("AI Quiz Generator error:", error);
      res.status(500).json({ error: error.message || "An error occurred while generating the quiz" });
    }
  });

  // AI Revision Note (Cheat Sheet) Generator
  app.post("/api/tutor/generate-notes", async (req, res) => {
    try {
      const { subject, topic } = req.body;
      const client = getGeminiClient();

      const prompt = `Generate a beautiful, concise, and comprehensive revision note or cheat sheet about "${topic}" in the subject "${subject}" for a Class 8 student.
      Include:
      1. A catchy introduction and high-level summary.
      2. 3-4 Key Formulae, Laws, or Core Concepts explained simply.
      3. A practical, real-world example or mnemonic device to help remember it.
      4. A "Common Traps to Avoid" section.
      
      Format your response beautifully in standard Markdown. Use clean headers, bullet points, bold highlighting, and horizontal dividers.`;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are an expert curriculum designer. Write high-contrast, premium, educational Markdown notes.",
          temperature: 0.6,
        }
      });

      res.json({ notes: response.text });
    } catch (error: any) {
      console.error("AI Revision Notes generator error:", error);
      res.status(500).json({ error: error.message || "An error occurred while generating revision notes" });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[DyanSetu Server] Running on http://localhost:${PORT} in ${process.env.NODE_ENV || "development"} mode`);
  });
}

startServer();
