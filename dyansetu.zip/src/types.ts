export interface Chapter {
  id: string;
  title: string;
  unit: string;
  completed: boolean;
  youtubeId: string; // The YouTube video ID (for hotlinking and embedding)
  playlistIndex?: number; // Optional index in a YouTube playlist
  durationMins: number;
}

export interface Subject {
  id: string;
  name: string;
  description: string;
  icon: string; // Lucide icon name
  progressPercent: number;
  colorClass: string; // bg-blue-100 text-blue-600, etc.
  accentColor: string; // blue, emerald, etc.
  chapters: Chapter[];
}

export interface VideoLecture {
  id: string;
  title: string;
  subject: string;
  chapter: string;
  unit: string;
  minutesLeft: number;
  durationMins: number;
  progressPercent: number;
  youtubeId: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
}

export interface GeneratedQuiz {
  title: string;
  questions: QuizQuestion[];
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: string;
}

export interface SavedNote {
  id: string;
  topic: string;
  subject: string;
  notesMarkdown: string;
  createdAt: string;
}

export interface QuizScoreHistory {
  id: string;
  quizTitle: string;
  subject: string;
  score: number;
  totalQuestions: number;
  date: string;
}

export type ActiveTab =
  | "dashboard"
  | "subjects"
  | "library"
  | "quiz"
  | "tutor"
  | "settings"
  | "support";
