import { Subject } from "./types";

// Dynamic Curriculum Database from Class 1 to Class 10
export const CLASS_CURRICULUM: Record<string, Subject[]> = {
  "Class 1": [
    {
      id: "math-1",
      name: "Mathematics",
      description: "Fun with numbers, basic addition, subtraction, counting shapes, and measurement.",
      icon: "Calculator",
      progressPercent: 15,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m1-c1", title: "Finding the Furry Cat!", unit: "Chapter 1", completed: true, youtubeId: "Nq1sMVScgig", durationMins: 10 },
        { id: "m1-c2", title: "What is Long? What is Round?", unit: "Chapter 2", completed: true, youtubeId: "ZTWfGZZhxQQ", durationMins: 12 },
        { id: "m1-c3", title: "Mango Treat", unit: "Chapter 3", completed: false, youtubeId: "HW0pypEWlNA", durationMins: 15 },
        { id: "m1-c4", title: "Making 10", unit: "Chapter 4", completed: false, youtubeId: "T1-QWVOpFA4", durationMins: 8 },
        { id: "m1-c5", title: "How Many?", unit: "Chapter 5", completed: false, youtubeId: "XiDhIe1SSqs", durationMins: 11 },
        { id: "m1-c6", title: "Vegetable Farm", unit: "Chapter 6", completed: false, youtubeId: "vxY55WB8XVE", durationMins: 9 },
        { id: "m1-c7", title: "Lina's Family", unit: "Chapter 7", completed: false, youtubeId: "yJmmy9x20qc", durationMins: 13 },
        { id: "m1-c8", title: "Fun with Numbers", unit: "Chapter 8", completed: false, youtubeId: "TUb8AXBYpXo", durationMins: 14 },
        { id: "m1-c9", title: "Utsav", unit: "Chapter 9", completed: false, youtubeId: "mSY6RsnttPI", durationMins: 10 },
        { id: "m1-c10", title: "How do I Spend My Day?", unit: "Chapter 10", completed: false, youtubeId: "Yron9DxGz0g", durationMins: 12 },
        { id: "m1-c11", title: "How Many Times?", unit: "Chapter 11", completed: false, youtubeId: "ipgL3N37-P8", durationMins: 15 },
        { id: "m1-c12", title: "How Much Can We Spend?", unit: "Chapter 12", completed: false, youtubeId: "ISo37CzOL78", durationMins: 11 },
        { id: "m1-c13", title: "So Many Toys (Data Handling)", unit: "Chapter 13", completed: false, youtubeId: "kgpL74T1nV0", durationMins: 9 }
      ]
    },
    {
      id: "hindi-1",
      name: "Hindi (Sarangi)",
      description: "Learn Hindi language, poems, stories and pronunciation with the beautiful Sarangi NCERT syllabus.",
      icon: "BookOpen",
      progressPercent: 0,
      colorClass: "bg-orange-100 dark:bg-orange-950 text-orange-600 dark:text-orange-300 border-orange-200 dark:border-orange-900",
      accentColor: "orange",
      chapters: [
        { id: "h1-c1", title: "मीना का परिवार", unit: "Chapter 1", completed: false, youtubeId: "EDXaU0T0fvU", durationMins: 10 },
        { id: "h1-c2", title: "दादा-दादी", unit: "Chapter 2", completed: false, youtubeId: "pjpKm21R3FI", durationMins: 11 },
        { id: "h1-c3", title: "रीना का दिन", unit: "Chapter 3", completed: false, youtubeId: "IxkoEpGzyxQ", durationMins: 12 },
        { id: "h1-c4", title: "रानी भी", unit: "Chapter 4", completed: false, youtubeId: "_AwSbAYmU_Q", durationMins: 9 },
        { id: "h1-c5", title: "मिठाई", unit: "Chapter 5", completed: false, youtubeId: "-Wr57lgj1QE", durationMins: 11 },
        { id: "h1-c6", title: "तीन साथी", unit: "Chapter 6", completed: false, youtubeId: "phEVNQcd80A", durationMins: 12 },
        { id: "h1-c7", title: "वाह, मेरे घोड़े!", unit: "Chapter 7", completed: false, youtubeId: "Ktfpg0sLqVE", durationMins: 10 },
        { id: "h1-c8", title: "खतरे में साँप", unit: "Chapter 8", completed: false, youtubeId: "_s8g2UaIUKc", durationMins: 8 },
        { id: "h1-c9", title: "आलू की सड़क", unit: "Chapter 9", completed: false, youtubeId: "0spT3exojc8", durationMins: 11 },
        { id: "h1-c10", title: "झूलम-झूली", unit: "Chapter 10", completed: false, youtubeId: "BKaDcmNY6CE", durationMins: 7 },
        { id: "h1-c11", title: "भुट्टे", unit: "Chapter 11", completed: false, youtubeId: "qpDh7Nzl2cE", durationMins: 10 },
        { id: "h1-c12", title: "फूली रोटी", unit: "Chapter 12", completed: false, youtubeId: "fz_ofyDJQF8", durationMins: 9 },
        { id: "h1-c13", title: "मेला", unit: "Chapter 13", completed: false, youtubeId: "SrGeAnUfA64", durationMins: 11 },
        { id: "h1-c14", title: "बरखा और मेघा", unit: "Chapter 14", completed: false, youtubeId: "DnOYwcTZ61U", durationMins: 12 },
        { id: "h1-c15", title: "होली", unit: "Chapter 15", completed: false, youtubeId: "BKaDcmNY6CE", durationMins: 10 },
        { id: "h1-c16", title: "जन्मदिन पर पेड़ लगाओ", unit: "Chapter 16", completed: false, youtubeId: "-APvw-LzJNs", durationMins: 9 },
        { id: "h1-c17", title: "हवा", unit: "Chapter 17", completed: false, youtubeId: "JwNZCCvsr2w", durationMins: 12 },
        { id: "h1-c18", title: "कितनी प्यारी है ये दुनिया", unit: "Chapter 18", completed: false, youtubeId: "NDk3b_6JP_0", durationMins: 11 },
        { id: "h1-c19", title: "चाँद का बच्चा", unit: "Chapter 19", completed: false, youtubeId: "Ma50DhFc5SI", durationMins: 10 }
      ]
    },
    {
      id: "english-1",
      name: "English Alphabet & Words",
      description: "Class 1 English syllabus containing lessons, stories, and activities based on the Mridang textbook.",
      icon: "BookOpen",
      progressPercent: 50,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e1-c1", title: "Two Little Hands", unit: "Unit 1", completed: true, youtubeId: "PLUgLcpnv1YieSi3k0ZnnUUfAzBIVOtd9H", playlistIndex: 1, durationMins: 10 },
        { id: "e1-c2", title: "Greetings", unit: "Unit 1", completed: false, youtubeId: "PLUgLcpnv1YieSi3k0ZnnUUfAzBIVOtd9H", playlistIndex: 2, durationMins: 12 },
        { id: "e1-c3", title: "Picture Time", unit: "Unit 1", completed: false, youtubeId: "PLUgLcpnv1YieSi3k0ZnnUUfAzBIVOtd9H", playlistIndex: 3, durationMins: 15 },
        { id: "e1-c4", title: "The Cap-seller and the Monkeys", unit: "Unit 2", completed: false, youtubeId: "zRNuttAv-A8", durationMins: 8 },
        { id: "e1-c5", title: "A Farm", unit: "Unit 2", completed: false, youtubeId: "PLUgLcpnv1YieSi3k0ZnnUUfAzBIVOtd9H", playlistIndex: 4, durationMins: 11 },
        { id: "e1-c6", title: "Fun with Pictures", unit: "Unit 2", completed: false, youtubeId: "PLUgLcpnv1YieSi3k0ZnnUUfAzBIVOtd9H", playlistIndex: 5, durationMins: 9 },
        { id: "e1-c7", title: "The Food We Eat", unit: "Unit 3", completed: false, youtubeId: "PLUgLcpnv1YieSi3k0ZnnUUfAzBIVOtd9H", playlistIndex: 6, durationMins: 14 },
        { id: "e1-c8", title: "The Four Seasons", unit: "Unit 4", completed: false, youtubeId: "PLUgLcpnv1YieSi3k0ZnnUUfAzBIVOtd9H", playlistIndex: 7, durationMins: 10 },
        { id: "e1-c9", title: "Anandi's Rainbow", unit: "Unit 4", completed: false, youtubeId: "PLUgLcpnv1YieSi3k0ZnnUUfAzBIVOtd9H", playlistIndex: 8, durationMins: 12 }
      ]
    },
    {
      id: "evs-1",
      name: "Environmental Studies",
      description: "Learning about my body, my family, green plants, friendly animals, and seasons.",
      icon: "FlaskConical",
      progressPercent: 10,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "evs1-c1", title: "Myself / About Myself", unit: "Chapter 1", completed: true, youtubeId: "IJl_FrHhG-g", durationMins: 10 },
        { id: "evs1-c2", title: "My Body", unit: "Chapter 2", completed: false, youtubeId: "gRAT-SbebGc", durationMins: 12 },
        { id: "evs1-c3", title: "My Family", unit: "Chapter 3", completed: false, youtubeId: "aOMNCu04NwI", durationMins: 11 },
        { id: "evs1-c4", title: "My School", unit: "Chapter 4", completed: false, youtubeId: "nT_NavhrxJw", durationMins: 13 },
        { id: "evs1-c5", title: "Food We Eat", unit: "Chapter 5", completed: false, youtubeId: "53SsdYAKGao", durationMins: 9 },
        { id: "evs1-c6", title: "Water", unit: "Chapter 6", completed: false, youtubeId: "JVUs-8IJQb4", durationMins: 10 },
        { id: "evs1-c7", title: "Plants Around Us", unit: "Chapter 7", completed: false, youtubeId: "UnCEv_J8VAo", durationMins: 12 },
        { id: "evs1-c8", title: "Animals Around Us", unit: "Chapter 8", completed: false, youtubeId: "lX7Yy5yK42A", durationMins: 15 },
        { id: "evs1-c9", title: "Means of Transport", unit: "Chapter 9", completed: false, youtubeId: "UOSFt3uuoMU", durationMins: 11 },
        { id: "evs1-c10", title: "Air and Water", unit: "Chapter 10", completed: false, youtubeId: "yhVGXJZV0W8", durationMins: 10 }
      ]
    }
  ],
  "Class 2": [
    {
      id: "math-2",
      name: "Mathematics (Joyful Maths)",
      description: "Counting in groups, 2D & 3D shapes, numbers up to 100, addition & subtraction, measurement, basic multiplication, division, and data handling.",
      icon: "Calculator",
      progressPercent: 18,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m2-c1", title: "A Day at the Beach (Counting in Groups)", unit: "Chapter 1", completed: true, youtubeId: "Fe8u2I6I8pI", durationMins: 12 },
        { id: "m2-c2", title: "Shapes Around Us (3D Shapes)", unit: "Chapter 2", completed: true, youtubeId: "p98T_vC5Ceg", durationMins: 11 },
        { id: "m2-c3", title: "Fun with Numbers (Numbers 1 to 100)", unit: "Chapter 3", completed: false, youtubeId: "b738L-fXid0", durationMins: 15 },
        { id: "m2-c4", title: "Shadow Story (Togalu) (2D Shapes)", unit: "Chapter 4", completed: false, youtubeId: "vxY55WB8XVE", durationMins: 13 },
        { id: "m2-c5", title: "Playing with Lines (Orientation of a Line)", unit: "Chapter 5", completed: false, youtubeId: "qpDh7Nzl2cE", durationMins: 10 },
        { id: "m2-c6", title: "Decoration for Festival (Addition & Subtraction)", unit: "Chapter 6", completed: false, youtubeId: "fz_ofyDJQF8", durationMins: 14 },
        { id: "m2-c7", title: "Rani's Gift (Measurement)", unit: "Chapter 7", completed: false, youtubeId: "Ktfpg0sLqVE", durationMins: 12 },
        { id: "m2-c8", title: "Grouping and Sharing (Multiplication & Division)", unit: "Chapter 8", completed: false, youtubeId: "DnOYwcTZ61U", durationMins: 15 },
        { id: "m2-c9", title: "Which Season is it? (Measurement of Time)", unit: "Chapter 9", completed: false, youtubeId: "JwNZCCvsr2w", durationMins: 11 },
        { id: "m2-c10", title: "Fun at the Fair (Money)", unit: "Chapter 10", completed: false, youtubeId: "NDk3b_6JP_0", durationMins: 13 },
        { id: "m2-c11", title: "Data Handling (Pictographs)", unit: "Chapter 11", completed: false, youtubeId: "Ma50DhFc5SI", durationMins: 10 }
      ]
    },
    {
      id: "english-2",
      name: "English (Mridang)",
      description: "Beautiful stories, poems, reading skills, and basic grammar based on the new Mridang textbook.",
      icon: "BookOpen",
      progressPercent: 15,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e2-c1", title: "My Bicycle (Unit 1)", unit: "Chapter 1", completed: true, youtubeId: "EDXaU0T0fvU", durationMins: 10 },
        { id: "e2-c2", title: "Picture Reading (Unit 1)", unit: "Chapter 2", completed: true, youtubeId: "pjpKm21R3FI", durationMins: 8 },
        { id: "e2-c3", title: "It is Fun (Unit 2)", unit: "Chapter 3", completed: false, youtubeId: "IxkoEpGzyxQ", durationMins: 11 },
        { id: "e2-c4", title: "Seeing without Seeing (Unit 2)", unit: "Chapter 4", completed: false, youtubeId: "_AwSbAYmU_Q", durationMins: 12 },
        { id: "e2-c5", title: "Come Back Soon (Unit 3)", unit: "Chapter 5", completed: false, youtubeId: "-Wr57lgj1QE", durationMins: 10 },
        { id: "e2-c6", title: "Between Home and School (Unit 3)", unit: "Chapter 6", completed: false, youtubeId: "phEVNQcd80A", durationMins: 13 },
        { id: "e2-c7", title: "This is My Town (Unit 3)", unit: "Chapter 7", completed: false, youtubeId: "Ktfpg0sLqVE", durationMins: 12 },
        { id: "e2-c8", title: "A Show of Clouds (Unit 4)", unit: "Chapter 8", completed: false, youtubeId: "_s8g2UaIUKc", durationMins: 9 },
        { id: "e2-c9", title: "My Name (Unit 4)", unit: "Chapter 9", completed: false, youtubeId: "0spT3exojc8", durationMins: 11 },
        { id: "e2-c10", title: "The Crow (Unit 4)", unit: "Chapter 10", completed: false, youtubeId: "BKaDcmNY6CE", durationMins: 10 },
        { id: "e2-c11", title: "The Smart Monkey (Unit 4)", unit: "Chapter 11", completed: false, youtubeId: "qpDh7Nzl2cE", durationMins: 12 },
        { id: "e2-c12", title: "Little Drops of Water (Unit 5)", unit: "Chapter 12", completed: false, youtubeId: "fz_ofyDJQF8", durationMins: 10 },
        { id: "e2-c13", title: "We are all Indians (Unit 5)", unit: "Chapter 13", completed: false, youtubeId: "SrGeAnUfA64", durationMins: 11 }
      ]
    },
    {
      id: "evs-2",
      name: "Environmental Studies",
      description: "Learn about about myself, our family, our amazing body, clothes we wear, shelter types, plants, animal friends, road safety, air & water.",
      icon: "FlaskConical",
      progressPercent: 21,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "evs2-c1", title: "About Me & My Identity", unit: "Chapter 1", completed: true, youtubeId: "IJl_FrHhG-g", durationMins: 10 },
        { id: "evs2-c2", title: "Others in My World (My Family)", unit: "Chapter 2", completed: true, youtubeId: "aOMNCu04NwI", durationMins: 12 },
        { id: "evs2-c3", title: "My Body & Internal Organs", unit: "Chapter 3", completed: true, youtubeId: "gRAT-SbebGc", durationMins: 11 },
        { id: "evs2-c4", title: "Food We Eat & Healthy Habits", unit: "Chapter 4", completed: false, youtubeId: "q4HIy_P_U4Q", durationMins: 10 },
        { id: "evs2-c5", title: "Clothes We Wear", unit: "Chapter 5", completed: false, youtubeId: "53SsdYAKGao", durationMins: 9 },
        { id: "evs2-c6", title: "Shelter & Types of Houses", unit: "Chapter 6", completed: false, youtubeId: "gFUgU7x7oGg", durationMins: 12 },
        { id: "evs2-c7", title: "My School & Community Helpers", unit: "Chapter 7", completed: false, youtubeId: "nT_NavhrxJw", durationMins: 13 },
        { id: "evs2-c8", title: "Neighbors & Festivals We Celebrate", unit: "Chapter 8", completed: false, youtubeId: "SrGeAnUfA6c", durationMins: 11 },
        { id: "evs2-c9", title: "Plants Around Us (Our Green Friends)", unit: "Chapter 9", completed: false, youtubeId: "UnCEv_J8VAb", durationMins: 12 },
        { id: "evs2-c10", title: "Animals Around Us (Our Animal Companions)", unit: "Chapter 10", completed: false, youtubeId: "lX7Yy5yK421", durationMins: 14 },
        { id: "evs2-c11", title: "Safety First: Road Safety Rules", unit: "Chapter 11", completed: false, youtubeId: "59ZlZ_-6p31", durationMins: 9 },
        { id: "evs2-c12", title: "Air and Water Sources", unit: "Chapter 12", completed: false, youtubeId: "JVUs-8IJQb1", durationMins: 11 },
        { id: "evs2-c13", title: "Weather and Seasons", unit: "Chapter 13", completed: false, youtubeId: "yhVGXJZV0W1", durationMins: 10 },
        { id: "evs2-c14", title: "Our Earth & Beautiful Sky", unit: "Chapter 14", completed: false, youtubeId: "y5gFI3pDd7a", durationMins: 12 }
      ]
    },
    {
      id: "hindi-2",
      name: "Hindi (Sarangi)",
      description: "Learn Class 2 Hindi with beautiful stories, poems, grammar, and activities from the Sarangi NCERT textbook.",
      icon: "BookOpen",
      progressPercent: 0,
      colorClass: "bg-orange-100 dark:bg-orange-950 text-orange-600 dark:text-orange-300 border-orange-200 dark:border-orange-900",
      accentColor: "orange",
      chapters: [
        { id: "h2-c1", title: "नीमा की दादी", unit: "Chapter 1", completed: false, youtubeId: "FAtQ2A-Yy-c", durationMins: 10 },
        { id: "h2-c2", title: "घर", unit: "Chapter 2", completed: false, youtubeId: "ZTWfGZZhxQQ", durationMins: 11 },
        { id: "h2-c3", title: "म्याऊँ, म्याऊँ!", unit: "Chapter 3", completed: false, youtubeId: "b738L-fXid0", durationMins: 12 },
        { id: "h2-c4", title: "अधिक बलवान कौन?", unit: "Chapter 4", completed: false, youtubeId: "vxY55WB8XVE", durationMins: 9 },
        { id: "h2-c5", title: "बहुत हुआ", unit: "Chapter 5", completed: false, youtubeId: "qpDh7Nzl2cE", durationMins: 11 },
        { id: "h2-c6", title: "छुक-छुक गाड़ी", unit: "Chapter 6", completed: false, youtubeId: "fz_ofyDJQF8", durationMins: 12 },
        { id: "h2-c7", title: "हमारी चिड़िया", unit: "Chapter 7", completed: false, youtubeId: "Ktfpg0sLqVE", durationMins: 10 },
        { id: "h2-c8", title: "मज़ेदार दिन", unit: "Chapter 8", completed: false, youtubeId: "DnOYwcTZ61U", durationMins: 8 },
        { id: "h2-c9", title: "माँ और बच्चे", unit: "Chapter 9", completed: false, youtubeId: "JwNZCCvsr2w", durationMins: 11 },
        { id: "h2-c10", title: "काम की बातें", unit: "Chapter 10", completed: false, youtubeId: "NDk3b_6JP_0", durationMins: 7 },
        { id: "h2-c11", title: "तितली", unit: "Chapter 11", completed: false, youtubeId: "Ma50DhFc5SI", durationMins: 10 },
        { id: "h2-c12", title: "शेर और चूहा", unit: "Chapter 12", completed: false, youtubeId: "EDXaU0T0fvU", durationMins: 9 },
        { id: "h2-c13", title: "तालाब", unit: "Chapter 13", completed: false, youtubeId: "phEVNQcd80A", durationMins: 11 },
        { id: "h2-c14", title: "चोको और कोको", unit: "Chapter 14", completed: false, youtubeId: "-Wr57lgj1QE", durationMins: 12 },
        { id: "h2-c15", title: "आनंदी का इंद्रधनुष", unit: "Chapter 15", completed: false, youtubeId: "pjpKm21R3FI", durationMins: 10 },
        { id: "h2-c16", title: "मूली", unit: "Chapter 16", completed: false, youtubeId: "-APvw-LzJNs", durationMins: 9 },
        { id: "h2-c17", title: "बरसात और मेंढक", unit: "Chapter 17", completed: false, youtubeId: "BKaDcmNY6CE", durationMins: 12 },
        { id: "h2-c18", title: "शेर और चूहे की दोस्ती", unit: "Chapter 18", completed: false, youtubeId: "yJmmy9x20qc", durationMins: 11 },
        { id: "h2-c19", title: "आउट", unit: "Chapter 19", completed: false, youtubeId: "ZTWfGZZhxQ1", durationMins: 10 },
        { id: "h2-c20", title: "छुपन छुपाई", unit: "Chapter 20", completed: false, youtubeId: "UOSFt3uuoMU", durationMins: 12 },
        { id: "h2-c21", title: "हँसमुख", unit: "Chapter 21", completed: false, youtubeId: "yhVGXJZV0W8", durationMins: 10 },
        { id: "h2-c22", title: "चित्रकारी", unit: "Chapter 22", completed: false, youtubeId: "ipgL3N37-P8", durationMins: 11 },
        { id: "h2-c23", title: "नक्शा", unit: "Chapter 23", completed: false, youtubeId: "ISo37CzOL78", durationMins: 12 },
        { id: "h2-c24", title: "गिरे ताल में चंदा मामा", unit: "Chapter 24", completed: false, youtubeId: "kgpL74T1nV0", durationMins: 10 },
        { id: "h2-c25", title: "सबसे बड़ा छाता", unit: "Chapter 25", completed: false, youtubeId: "Nq1sMVScgig", durationMins: 11 },
        { id: "h2-c26", title: "बादल", unit: "Chapter 26", completed: false, youtubeId: "SrGeAnUfA64", durationMins: 12 }
      ]
    }
  ],
  "Class 3": [
    {
      id: "math-3",
      name: "Mathematics",
      description: "Intro to Multiplication, Division, 3-digit numbers, Patterns, and Money calculations.",
      icon: "Calculator",
      progressPercent: 40,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m3-c1", title: "Where to Look From? (Symmetry)", unit: "Unit 1", completed: true, youtubeId: "nt43FJQppCQ", durationMins: 12 },
        { id: "m3-c2", title: "Fun with 3-Digit Numbers", unit: "Unit 2", completed: false, youtubeId: "P87CA4rI__w", durationMins: 15 },
        { id: "m3-c3", title: "Multiplication Basics & Tables", unit: "Unit 3", completed: false, youtubeId: "dR4GicI_6lc", durationMins: 18 }
      ]
    },
    {
      id: "science-3",
      name: "Science & Nature",
      description: "Living vs Non-Living things, parts of a plant, eating habits of animals, and birds.",
      icon: "FlaskConical",
      progressPercent: 60,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "s3-c1", title: "Living & Non-Living Things around us", unit: "Unit 1", completed: true, youtubeId: "za5z6WRz29I", durationMins: 12 },
        { id: "s3-c2", title: "Parts of a Plant & their Tasks", unit: "Unit 2", completed: true, youtubeId: "Vo8S4kXwivQ", durationMins: 15 },
        { id: "s3-c3", title: "Birds: Feathers, Beaks & Nests", unit: "Unit 3", completed: false, youtubeId: "GPPV10wDNHA", durationMins: 14 }
      ]
    }
  ],
  "Class 4": [
    {
      id: "english-4",
      name: "English",
      description: "Class 4 English lessons, stories, and poems from the CBSE NCERT Marigold textbook.",
      icon: "BookOpen",
      progressPercent: 40,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e4-c1", title: "Wake Up!", unit: "Chapter 1", completed: true, youtubeId: "vEhHhuNVVmY", durationMins: 10 },
        { id: "e4-c2", title: "Neha's Alarm Clock", unit: "Chapter 2", completed: false, youtubeId: "oLX5SLrTzWs", durationMins: 12 },
        { id: "e4-c3", title: "Noses", unit: "Chapter 3", completed: false, youtubeId: "Jrckgw7Ho_w", durationMins: 11 },
        { id: "e4-c4", title: "The Little Fir Tree", unit: "Chapter 4", completed: false, youtubeId: "FPBsgv7AtGY", durationMins: 14 },
        { id: "e4-c5", title: "Run!", unit: "Chapter 5", completed: false, youtubeId: "jsecYsNiScU", durationMins: 10 }
      ]
    },
    {
      id: "hindi-4",
      name: "Hindi (Rimjhim)",
      description: "Learn Class 4 Hindi with beautiful poems, stories, and vocabulary from the Rimjhim textbook.",
      icon: "BookOpen",
      progressPercent: 30,
      colorClass: "bg-orange-100 dark:bg-orange-950 text-orange-600 dark:text-orange-300 border-orange-200 dark:border-orange-900",
      accentColor: "orange",
      chapters: [
        { id: "h4-c1", title: "मन के भोले-भाले बादल", unit: "Chapter 1", completed: true, youtubeId: "lAydYIQdeDE", durationMins: 12 },
        { id: "h4-c2", title: "जैसा सवाल वैसा जवाब", unit: "Chapter 2", completed: false, youtubeId: "lVavbVAeeZw", durationMins: 14 },
        { id: "h4-c3", title: "किरमिच की गेंद", unit: "Chapter 3", completed: false, youtubeId: "LAQbkTmEhRo", durationMins: 15 },
        { id: "h4-c4", title: "पापा जब बच्चे थे", unit: "Chapter 4", completed: false, youtubeId: "Es9HIm1zJX8", durationMins: 13 },
        { id: "h4-c5", title: "दोस्त की पोशाक", unit: "Chapter 5", completed: false, youtubeId: "jw_4Y6lQWXo", durationMins: 12 }
      ]
    },
    {
      id: "math-4",
      name: "Mathematics",
      description: "Interactive learning of numbers, shapes, lengths, times, and trips for Class 4 Maths.",
      icon: "Calculator",
      progressPercent: 50,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m4-c1", title: "Building with Bricks", unit: "Chapter 1", completed: true, youtubeId: "dweRs6ON6-s", durationMins: 14 },
        { id: "m4-c2", title: "Long and Short", unit: "Chapter 2", completed: false, youtubeId: "Wx8kPgPOqZ0", durationMins: 16 },
        { id: "m4-c3", title: "A Trip to Bhopal", unit: "Chapter 3", completed: false, youtubeId: "M_rKoAbCi8w", durationMins: 15 },
        { id: "m4-c4", title: "Tick-Tick-Tick", unit: "Chapter 4", completed: false, youtubeId: "cJUAtvs0XYM", durationMins: 12 },
        { id: "m4-c5", title: "The Way the World Looks", unit: "Chapter 5", completed: false, youtubeId: "ZGIlTm8eVzA", durationMins: 14 }
      ]
    },
    {
      id: "science-4",
      name: "Science",
      description: "Explore the surrounding world, animal ears, honeybees, plant life, and transport for Class 4 EVS.",
      icon: "FlaskConical",
      progressPercent: 45,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "s4-c1", title: "Going to School", unit: "Chapter 1", completed: true, youtubeId: "gFUgU7x7oGg", durationMins: 15 },
        { id: "s4-c2", title: "Ear to Ear", unit: "Chapter 2", completed: false, youtubeId: "q4HIy_P_U4Q", durationMins: 18 },
        { id: "s4-c3", title: "A Day with Nandu", unit: "Chapter 3", completed: false, youtubeId: "59ZlZ_-6p34", durationMins: 20 },
        { id: "s4-c4", title: "The Story of Amrita", unit: "Chapter 4", completed: false, youtubeId: "IJl_FrHhG-g", durationMins: 16 },
        { id: "s4-c5", title: "Anita and the Honeybees", unit: "Chapter 5", completed: false, youtubeId: "UnCEv_J8VAo", durationMins: 15 }
      ]
    },
    {
      id: "history-4",
      name: "History (Our Pasts)",
      description: "Journey through human history, early civilization, Vedic culture, and ancient empires.",
      icon: "History",
      progressPercent: 25,
      colorClass: "bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-300 border-purple-200 dark:border-purple-900",
      accentColor: "purple",
      chapters: [
        { id: "h4-hist-c1", title: "Our Past I", unit: "Chapter 1", completed: true, youtubeId: "9O8w20Xh6S0", durationMins: 22 },
        { id: "h4-hist-c2", title: "Early Humans", unit: "Chapter 2", completed: false, youtubeId: "kKKM8Y-g7lk", durationMins: 24 },
        { id: "h4-hist-c3", title: "The Indus Valley Civilization", unit: "Chapter 3", completed: false, youtubeId: "aU9YFvN-U_s", durationMins: 26 },
        { id: "h4-hist-c4", title: "The Vedic Age", unit: "Chapter 4", completed: false, youtubeId: "0_D6LgXvTjA", durationMins: 25 },
        { id: "h4-hist-c5", title: "The Mauryan Empire", unit: "Chapter 5", completed: false, youtubeId: "XQx9P2G6R7A", durationMins: 28 }
      ]
    },
    {
      id: "geography-4",
      name: "Geography",
      description: "Discover our planet, global mapping, geographical features of India, and state locations.",
      icon: "BookOpen",
      progressPercent: 35,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "g4-c1", title: "Our Earth", unit: "Chapter 1", completed: true, youtubeId: "y5gFI3pDd74", durationMins: 18 },
        { id: "g4-c2", title: "The Globe", unit: "Chapter 2", completed: false, youtubeId: "Z-M4XoK_17A", durationMins: 20 },
        { id: "g4-c3", title: "Maps", unit: "Chapter 3", completed: false, youtubeId: "ISo37CzOL78", durationMins: 16 },
        { id: "g4-c4", title: "India: Physical Features", unit: "Chapter 4", completed: false, youtubeId: "yJmmy9x20qc", durationMins: 22 },
        { id: "g4-c5", title: "States and Capitals", unit: "Chapter 5", completed: false, youtubeId: "SrGeAnUfA64", durationMins: 24 }
      ]
    }
  ],
  "Class 5": [
    {
      id: "math-5",
      name: "Mathematics",
      description: "Dive into big numbers, spatial design, angles, parts and wholes, and symmetry.",
      icon: "Calculator",
      progressPercent: 40,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m5-c1", title: "The Fish Tale", unit: "Chapter 1", completed: true, youtubeId: "nH2yoBrweE8", durationMins: 15 },
        { id: "m5-c2", title: "Shapes and Angles", unit: "Chapter 2", completed: true, youtubeId: "o4pbMUTSv-w", durationMins: 18 },
        { id: "m5-c3", title: "How Many Squares?", unit: "Chapter 3", completed: false, youtubeId: "gKKpPMkyvsk", durationMins: 20 },
        { id: "m5-c4", title: "Parts and Wholes", unit: "Chapter 4", completed: false, youtubeId: "Yh0KHQ1J77I", durationMins: 16 },
        { id: "m5-c5", title: "Does It Look the Same?", unit: "Chapter 5", completed: false, youtubeId: "9kJ2K1dOYiw", durationMins: 14 }
      ]
    },
    {
      id: "science-5",
      name: "Science",
      description: "Learn about the plant kingdom, animals around us, our complex body, and natural elements.",
      icon: "FlaskConical",
      progressPercent: 60,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "s5-c1", title: "Plants Around Us", unit: "Chapter 1", completed: true, youtubeId: "VN_x1clV1Ng", durationMins: 16 },
        { id: "s5-c2", title: "Animals Around Us", unit: "Chapter 2", completed: true, youtubeId: "tlypZMw8vo0", durationMins: 18 },
        { id: "s5-c3", title: "Our Body", unit: "Chapter 3", completed: false, youtubeId: "GYtJKrbqhiQ", durationMins: 15 },
        { id: "s5-c4", title: "Food and Health", unit: "Chapter 4", completed: false, youtubeId: "7FJKxHcITEI", durationMins: 20 },
        { id: "s5-c5", title: "Air and Water", unit: "Chapter 5", completed: false, youtubeId: "nrptzwQEB30", durationMins: 18 }
      ]
    },
    {
      id: "english-5",
      name: "English",
      description: "Charming stories, creative vocabulary, teamwork, and reading comprehension.",
      icon: "BookOpen",
      progressPercent: 20,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e5-c1", title: "Ice-cream Man", unit: "Chapter 1", completed: false, youtubeId: "ETc1bdM6-CM", durationMins: 12 },
        { id: "e5-c2", title: "Wonderful Waste!", unit: "Chapter 2", completed: false, youtubeId: "Jm4HT3w_VUQ", durationMins: 14 },
        { id: "e5-c3", title: "Teamwork", unit: "Chapter 3", completed: false, youtubeId: "OY7Dnbb7HI8", durationMins: 11 },
        { id: "e5-c4", title: "Flying Together", unit: "Chapter 4", completed: false, youtubeId: "rlYz1zz4Ogs", durationMins: 15 },
        { id: "e5-c5", title: "My Shadow", unit: "Chapter 5", completed: false, youtubeId: "FKSP8Efd94Y", durationMins: 13 }
      ]
    },
    {
      id: "history-5",
      name: "History",
      description: "Chronicles of early settlements, ancient global civilisations, and dynastic heritage.",
      icon: "History",
      progressPercent: 10,
      colorClass: "bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-300 border-purple-200 dark:border-purple-900",
      accentColor: "purple",
      chapters: [
        { id: "h5-c1", title: "Early Settlements", unit: "Chapter 1", completed: false, youtubeId: "9O8w20Xh6S1", durationMins: 22 },
        { id: "h5-c2", title: "Ancient Civilizations", unit: "Chapter 2", completed: false, youtubeId: "kKKM8Y-g7l1", durationMins: 25 },
        { id: "h5-c3", title: "Kings and Kingdoms", unit: "Chapter 3", completed: false, youtubeId: "aU9YFvN-U_1", durationMins: 28 },
        { id: "h5-c4", title: "Great Leaders", unit: "Chapter 4", completed: false, youtubeId: "XQx9P2G6R71", durationMins: 24 },
        { id: "h5-c5", title: "Our Heritage", unit: "Chapter 5", completed: false, youtubeId: "0_D6LgXvTj1", durationMins: 26 }
      ]
    },
    {
      id: "geography-5",
      name: "Geography",
      description: "Explore the Earth, understand map directions, and study natural landscapes and resources.",
      icon: "BookOpen",
      progressPercent: 30,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "g5-c1", title: "The Earth", unit: "Chapter 1", completed: false, youtubeId: "SrGeAnUfA61", durationMins: 18 },
        { id: "g5-c2", title: "Maps and Directions", unit: "Chapter 2", completed: false, youtubeId: "Z-M4XoK_171", durationMins: 20 },
        { id: "g5-c3", title: "Landforms", unit: "Chapter 3", completed: false, youtubeId: "ISo37CzOL71", durationMins: 16 },
        { id: "g5-c4", title: "Weather and Climate", unit: "Chapter 4", completed: false, youtubeId: "yJmmy9x20q1", durationMins: 22 },
        { id: "g5-c5", title: "Natural Resources", unit: "Chapter 5", completed: false, youtubeId: "y5gFI3pDd72", durationMins: 24 }
      ]
    }
  ],
  "Class 6": [
    {
      id: "math-6",
      name: "Mathematics",
      description: "Knowing numbers, playing with factors, and geometry design fundamentals.",
      icon: "Calculator",
      progressPercent: 50,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m6-c1", title: "Knowing Our Numbers", unit: "Chapter 1", completed: true, youtubeId: "4OvGeKbi6UM", durationMins: 22 },
        { id: "m6-c2", title: "Whole Numbers", unit: "Chapter 2", completed: false, youtubeId: "kQcE8QGDALA", durationMins: 20 },
        { id: "m6-c3", title: "Playing with Numbers", unit: "Chapter 3", completed: false, youtubeId: "NNFqyAGtbZM", durationMins: 24 },
        { id: "m6-c4", title: "Basic Geometrical Ideas", unit: "Chapter 4", completed: false, youtubeId: "L9wBhBmvNx0", durationMins: 18 },
        { id: "m6-c5", title: "Understanding Elementary Shapes", unit: "Chapter 5", completed: false, youtubeId: "cjJZx-UjYiw", durationMins: 22 }
      ]
    },
    {
      id: "science-6",
      name: "Science",
      description: "Discover food sources, fibre production, materials classification, and separation of mixtures.",
      icon: "FlaskConical",
      progressPercent: 35,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "s6-c1", title: "Food: Where Does It Come From?", unit: "Chapter 1", completed: true, youtubeId: "5tdqsng76Fo", durationMins: 20 },
        { id: "s6-c2", title: "Components of Food", unit: "Chapter 2", completed: false, youtubeId: "bblkgyxjs_A", durationMins: 18 },
        { id: "s6-c3", title: "Fibre to Fabric", unit: "Chapter 3", completed: false, youtubeId: "ABRI_dugwPI", durationMins: 22 },
        { id: "s6-c4", title: "Sorting Materials into Groups", unit: "Chapter 4", completed: false, youtubeId: "be0iSECGhwM", durationMins: 25 },
        { id: "s6-c5", title: "Separation of Substances", unit: "Chapter 5", completed: false, youtubeId: "yMBa5GAYEPc", durationMins: 18 }
      ]
    },
    {
      id: "english-6",
      name: "English",
      description: "Classic classroom stories, Patrick's homework adventure, and inspiring historical paths.",
      icon: "BookOpen",
      progressPercent: 40,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e6-c1", title: "Who Did Patrick's Homework?", unit: "Chapter 1", completed: true, youtubeId: "P4SzdHgDu3Q", durationMins: 15 },
        { id: "e6-c2", title: "How the Dog Found Himself", unit: "Chapter 2", completed: false, youtubeId: "QngWG7OXZ6s", durationMins: 16 },
        { id: "e6-c3", title: "Taro's Reward", unit: "Chapter 3", completed: false, youtubeId: "iUm3Ac_RiKE", durationMins: 14 },
        { id: "e6-c4", title: "An Indian-American Woman in Space", unit: "Chapter 4", completed: false, youtubeId: "CCRdiLymems", durationMins: 18 },
        { id: "e6-c5", title: "A Different Kind of School", unit: "Chapter 5", completed: false, youtubeId: "HF-j0aen4BA", durationMins: 12 }
      ]
    },
    {
      id: "history-6",
      name: "History",
      description: "Tracing back early human records, hunting-gathering transformations, and early cities.",
      icon: "History",
      progressPercent: 20,
      colorClass: "bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-300 border-purple-200 dark:border-purple-900",
      accentColor: "purple",
      chapters: [
        { id: "h6-c1", title: "What, Where, How and When?", unit: "Chapter 1", completed: false, youtubeId: "wwORVr9Og0o", durationMins: 24 },
        { id: "h6-c2", title: "From Hunting-Gathering to Growing Food", unit: "Chapter 2", completed: false, youtubeId: "rf_dgWj6iks", durationMins: 26 },
        { id: "h6-c3", title: "In the Earliest Cities", unit: "Chapter 3", completed: false, youtubeId: "Yhdj6nfhp9w", durationMins: 28 },
        { id: "h6-c4", title: "What Books and Burials Tell Us", unit: "Chapter 4", completed: false, youtubeId: "JTUWiwoTvnU", durationMins: 25 },
        { id: "h6-c5", title: "Kingdoms, Kings and an Early Republic", unit: "Chapter 5", completed: false, youtubeId: "vwm4XDgzFGg", durationMins: 27 }
      ]
    },
    {
      id: "geography-6",
      name: "Geography",
      description: "Discover our dynamic solar system, geographic latitude, longitude, and world maps.",
      icon: "BookOpen",
      progressPercent: 30,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "g6-c1", title: "The Earth in the Solar System", unit: "Chapter 1", completed: false, youtubeId: "7F9IH-w0SKY", durationMins: 20 },
        { id: "g6-c2", title: "Globe: Latitudes and Longitudes", unit: "Chapter 2", completed: false, youtubeId: "hntFjVk3UuI", durationMins: 22 },
        { id: "g6-c3", title: "Motions of the Earth", unit: "Chapter 3", completed: false, youtubeId: "5RNrL-oGII4", durationMins: 18 },
        { id: "g6-c4", title: "Maps", unit: "Chapter 4", completed: false, youtubeId: "9jIL1MiYGnQ", durationMins: 16 },
        { id: "g6-c5", title: "Major Domains of the Earth", unit: "Chapter 5", completed: false, youtubeId: "R2l43-q2yy8", durationMins: 24 }
      ]
    }
  ],
  "Class 7": [
    {
      id: "math-7",
      name: "Mathematics",
      description: "Integers properties, fractions and decimals operations, algebraic equations, and geometry.",
      icon: "Calculator",
      progressPercent: 45,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m7-c1", title: "Integers", unit: "Chapter 1", completed: true, youtubeId: "s0QF8zRNwrg", durationMins: 25 },
        { id: "m7-c2", title: "Fractions and Decimals", unit: "Chapter 2", completed: false, youtubeId: "YrTtt0lsJYY", durationMins: 22 },
        { id: "m7-c3", title: "Data Handling", unit: "Chapter 3", completed: false, youtubeId: "IcKxZXhQBJU", durationMins: 24 },
        { id: "m7-c4", title: "Simple Equations", unit: "Chapter 4", completed: false, youtubeId: "W6MKuAnB0h4", durationMins: 20 },
        { id: "m7-c5", title: "Lines and Angles", unit: "Chapter 5", completed: false, youtubeId: "nEYldznpZmk", durationMins: 26 }
      ]
    },
    {
      id: "science-7",
      name: "Science",
      description: "Plant and animal nutrition, fibres, heat, and complex chemical processes.",
      icon: "FlaskConical",
      progressPercent: 55,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "s7-c1", title: "Nutrition in Plants", unit: "Chapter 1", completed: true, youtubeId: "oP2sbq9G5PI", durationMins: 22 },
        { id: "s7-c2", title: "Nutrition in Animals", unit: "Chapter 2", completed: false, youtubeId: "Ho8bmT4dsKE", durationMins: 24 },
        { id: "s7-c3", title: "Fibre to Fabric", unit: "Chapter 3", completed: false, youtubeId: "ABRI_dugwPI", durationMins: 20 },
        { id: "s7-c4", title: "Heat", unit: "Chapter 4", completed: false, youtubeId: "6aBrvrCqbYI", durationMins: 18 },
        { id: "s7-c5", title: "Acids, Bases and Salts", unit: "Chapter 5", completed: false, youtubeId: "5bSXK0QttdY", durationMins: 25 }
      ]
    },
    {
      id: "english-7",
      name: "English",
      description: "Three profound questions, Gopal's clever wit, and classic narratives.",
      icon: "BookOpen",
      progressPercent: 30,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e7-c1", title: "Three Questions", unit: "Chapter 1", completed: false, youtubeId: "wqsTeK1XYK8", durationMins: 15 },
        { id: "e7-c2", title: "A Gift of Chappals", unit: "Chapter 2", completed: false, youtubeId: "_mN1kD3_1aI", durationMins: 18 },
        { id: "e7-c3", title: "Gopal and the Hilsa Fish", unit: "Chapter 3", completed: false, youtubeId: "ox-aC8UuExQ", durationMins: 14 },
        { id: "e7-c4", title: "The Ashes That Made Trees Bloom", unit: "Chapter 4", completed: false, youtubeId: "9MF2vBSZ4fM", durationMins: 16 },
        { id: "e7-c5", title: "Quality", unit: "Chapter 5", completed: false, youtubeId: "XTabRijQmPw", durationMins: 12 }
      ]
    },
    {
      id: "history-7",
      name: "History",
      description: "Tracing a thousand years of societal shifts, the Delhi sultanate, and Mughal empire architecture.",
      icon: "History",
      progressPercent: 20,
      colorClass: "bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-300 border-purple-200 dark:border-purple-900",
      accentColor: "purple",
      chapters: [
        { id: "h7-c1", title: "Tracing Changes Through a Thousand Years", unit: "Chapter 1", completed: false, youtubeId: "AcJzSFwCfWs", durationMins: 25 },
        { id: "h7-c2", title: "New Kings and Kingdoms", unit: "Chapter 2", completed: false, youtubeId: "vY0RT-utpek", durationMins: 28 },
        { id: "h7-c3", title: "The Delhi Sultans", unit: "Chapter 3", completed: false, youtubeId: "V6Pb2cuerk4", durationMins: 30 },
        { id: "h7-c4", title: "The Mughal Empire", unit: "Chapter 4", completed: false, youtubeId: "HCumu07LtTo", durationMins: 32 },
        { id: "h7-c5", title: "Tribes, Nomads and Settled Communities", unit: "Chapter 5", completed: false, youtubeId: "AL3JeXPoj3E", durationMins: 26 }
      ]
    },
    {
      id: "geography-7",
      name: "Geography",
      description: "Dynamic environmental studies, our changing active Earth crust, air currents, and water resources.",
      icon: "BookOpen",
      progressPercent: 35,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "g7-c1", title: "Environment", unit: "Chapter 1", completed: false, youtubeId: "bVu4j5AIEno", durationMins: 16 },
        { id: "g7-c2", title: "Inside Our Earth", unit: "Chapter 2", completed: false, youtubeId: "rp7tAGlfKSQ", durationMins: 18 },
        { id: "g7-c3", title: "Our Changing Earth", unit: "Chapter 3", completed: false, youtubeId: "b4e88zjBBvU", durationMins: 20 },
        { id: "g7-c4", title: "Air", unit: "Chapter 4", completed: false, youtubeId: "qggk5vMBxLY", durationMins: 15 },
        { id: "g7-c5", title: "Water", unit: "Chapter 5", completed: false, youtubeId: "Pu5QPfK-ask", durationMins: 22 }
      ]
    }
  ],
  "Class 8": [
    {
      id: "math-8",
      name: "Mathematics",
      description: "Explore algebraic logic, equations, rational number fields, and quadrilateral shapes.",
      icon: "Calculator",
      progressPercent: 50,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m8-c1", title: "Rational Numbers", unit: "Chapter 1", completed: true, youtubeId: "KkUPmbL0F-Q", durationMins: 32 },
        { id: "m8-c2", title: "Linear Equations in One Variable", unit: "Chapter 2", completed: false, youtubeId: "FdS7KIVfks0", durationMins: 28 },
        { id: "m8-c3", title: "Understanding Quadrilaterals", unit: "Chapter 3", completed: false, youtubeId: "I3vp_4WIiVo", durationMins: 25 },
        { id: "m8-c4", title: "Practical Geometry", unit: "Chapter 4", completed: false, youtubeId: "z3gDmpLA1tY", durationMins: 30 },
        { id: "m8-c5", title: "Data Handling", unit: "Chapter 5", completed: false, youtubeId: "01nxKH9PNIs", durationMins: 26 }
      ]
    },
    {
      id: "science-8",
      name: "Science",
      description: "Crop production, microbial world, materials and fuels, and metal assets.",
      icon: "FlaskConical",
      progressPercent: 40,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "s8-c1", title: "Crop Production and Management", unit: "Chapter 1", completed: true, youtubeId: "oD5tSwKfueo", durationMins: 25 },
        { id: "s8-c2", title: "Microorganisms: Friend and Foe", unit: "Chapter 2", completed: false, youtubeId: "k3Q9L798tAk", durationMins: 28 },
        { id: "s8-c3", title: "Synthetic Fibres and Plastics", unit: "Chapter 3", completed: false, youtubeId: "ff6wvfel0MQ", durationMins: 22 },
        { id: "s8-c4", title: "Materials: Metals and Non-Metals", unit: "Chapter 4", completed: false, youtubeId: "EvtPkGCHTVk", durationMins: 30 },
        { id: "s8-c5", title: "Coal and Petroleum", unit: "Chapter 5", completed: false, youtubeId: "gza1p6pD02E", durationMins: 24 }
      ]
    },
    {
      id: "english-8",
      name: "English",
      description: "Historic prose, natural disasters, memory loss stories, and peak conquests.",
      icon: "BookOpen",
      progressPercent: 60,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e8-c1", title: "The Best Christmas Present in the World", unit: "Chapter 1", completed: true, youtubeId: "JiLis0KBQf0", durationMins: 22 },
        { id: "e8-c2", title: "The Tsunami", unit: "Chapter 2", completed: false, youtubeId: "ZQfYr8Yob-M", durationMins: 20 },
        { id: "e8-c3", title: "Glimpses of the Past", unit: "Chapter 3", completed: false, youtubeId: "3TlzXIWBz2U", durationMins: 24 },
        { id: "e8-c4", title: "Bepin Choudhury's Lapse of Memory", unit: "Chapter 4", completed: false, youtubeId: "KvAGCk3PepA", durationMins: 26 },
        { id: "e8-c5", title: "The Summit Within", unit: "Chapter 5", completed: false, youtubeId: "r6Rbyv6-m34", durationMins: 18 }
      ]
    },
    {
      id: "history-8",
      name: "History",
      description: "Indian modern history, East India Company operations, and freedom rebellion.",
      icon: "History",
      progressPercent: 30,
      colorClass: "bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-300 border-purple-200 dark:border-purple-900",
      accentColor: "purple",
      chapters: [
        { id: "h8-c1", title: "How, When and Where", unit: "Chapter 1", completed: true, youtubeId: "LJ_kV3Q1Dro", durationMins: 25 },
        { id: "h8-c2", title: "From Trade to Territory", unit: "Chapter 2", completed: false, youtubeId: "sXg02QhAMQQ", durationMins: 30 },
        { id: "h8-c3", title: "Ruling the Countryside", unit: "Chapter 3", completed: false, youtubeId: "_SASgYGUcpY", durationMins: 28 },
        { id: "h8-c4", title: "Tribals, Dikus and the Vision of a Golden Age", unit: "Chapter 4", completed: false, youtubeId: "_ZyW2jaKsX4", durationMins: 35 },
        { id: "h8-c5", title: "When People Rebel", unit: "Chapter 5", completed: false, youtubeId: "vsBdAjbs8bc", durationMins: 32 }
      ]
    },
    {
      id: "geography-8",
      name: "Geography",
      description: "Global resources, mineral wealth, agriculture farming, and industrial assets.",
      icon: "BookOpen",
      progressPercent: 35,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "g8-c1", title: "Resources", unit: "Chapter 1", completed: false, youtubeId: "9gwi0kWspoE", durationMins: 18 },
        { id: "g8-c2", title: "Land, Soil, Water, Natural Vegetation and Wildlife Resources", unit: "Chapter 2", completed: false, youtubeId: "SNsLP1rbBHk", durationMins: 25 },
        { id: "g8-c3", title: "Mineral and Power Resources", unit: "Chapter 3", completed: false, youtubeId: "1PT412oAPX4", durationMins: 22 },
        { id: "g8-c4", title: "Agriculture", unit: "Chapter 4", completed: false, youtubeId: "AjiugzmRJm0", durationMins: 20 },
        { id: "g8-c5", title: "Industries", unit: "Chapter 5", completed: false, youtubeId: "w8Qq36E_4NA", durationMins: 24 }
      ]
    }
  ],
  "Class 9": [
    {
      id: "math-9",
      name: "Mathematics",
      description: "Advance through coordinate systems, number domains, polynomials, and Euclid's geometry.",
      icon: "Calculator",
      progressPercent: 40,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m9-c1", title: "Number Systems", unit: "Chapter 1", completed: true, youtubeId: "IMnSIaPcqiE", durationMins: 30 },
        { id: "m9-c2", title: "Polynomials", unit: "Chapter 2", completed: false, youtubeId: "4VHrvMutJQw", durationMins: 32 },
        { id: "m9-c3", title: "Coordinate Geometry", unit: "Chapter 3", completed: false, youtubeId: "3MIZUl6bWxY", durationMins: 28 },
        { id: "m9-c4", title: "Linear Equations in Two Variables", unit: "Chapter 4", completed: false, youtubeId: "rnudiJxVXxM", durationMins: 30 },
        { id: "m9-c5", title: "Introduction to Euclid's Geometry", unit: "Chapter 5", completed: false, youtubeId: "mxeXcTjQiuM", durationMins: 26 }
      ]
    },
    {
      id: "science-9",
      name: "Science",
      description: "Matter properties, atomic configurations, molecules, and fundamental life cells.",
      icon: "FlaskConical",
      progressPercent: 50,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "s9-c1", title: "Matter in Our Surroundings", unit: "Chapter 1", completed: true, youtubeId: "bmzDsWMSCTk", durationMins: 26 },
        { id: "s9-c2", title: "Is Matter Around Us Pure?", unit: "Chapter 2", completed: false, youtubeId: "tjl1gtYhYsI", durationMins: 28 },
        { id: "s9-c3", title: "Atoms and Molecules", unit: "Chapter 3", completed: false, youtubeId: "Jy2bLuZU8ps", durationMins: 35 },
        { id: "s9-c4", title: "Structure of the Atom", unit: "Chapter 4", completed: false, youtubeId: "0UqHoagKXts", durationMins: 32 },
        { id: "s9-c5", title: "The Fundamental Unit of Life", unit: "Chapter 5", completed: false, youtubeId: "LTaq4yHNtSk", durationMins: 30 }
      ]
    },
    {
      id: "english-9",
      name: "English",
      description: "The music of sound, historical school dynamics, and poetic imagery.",
      icon: "BookOpen",
      progressPercent: 50,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e9-c1", title: "The Fun They Had", unit: "Chapter 1", completed: true, youtubeId: "A30OuLLUa-g", durationMins: 15 },
        { id: "e9-c2", title: "The Sound of Music", unit: "Chapter 2", completed: false, youtubeId: "W5MpRd5g0uY", durationMins: 20 },
        { id: "e9-c3", title: "The Little Girl", unit: "Chapter 3", completed: false, youtubeId: "0aKcX6eqa9w", durationMins: 16 },
        { id: "e9-c4", title: "A Truly Beautiful Mind", unit: "Chapter 4", completed: false, youtubeId: "KzcbaKAaBVc", durationMins: 18 },
        { id: "e9-c5", title: "The Snake and the Mirror", unit: "Chapter 5", completed: false, youtubeId: "nViom0_nfk4", durationMins: 15 }
      ]
    },
    {
      id: "history-9",
      name: "History",
      description: "French revolution records, rise of Nazism, forest societies, and pastoral lifecycles.",
      icon: "History",
      progressPercent: 25,
      colorClass: "bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-300 border-purple-200 dark:border-purple-900",
      accentColor: "purple",
      chapters: [
        { id: "h9-c1", title: "The French Revolution", unit: "Chapter 1", completed: true, youtubeId: "PJaUqX9KQW0", durationMins: 32 },
        { id: "h9-c2", title: "Socialism in Europe and the Russian Revolution", unit: "Chapter 2", completed: false, youtubeId: "V1K-bhiaV9w", durationMins: 35 },
        { id: "h9-c3", title: "Nazism and the Rise of Hitler", unit: "Chapter 3", completed: false, youtubeId: "goEZfKiuu0Q", durationMins: 38 },
        { id: "h9-c4", title: "Forest Society and Colonialism", unit: "Chapter 4", completed: false, youtubeId: "6cdwmD6xx24", durationMins: 28 },
        { id: "h9-c5", title: "Pastoralists in the Modern World", unit: "Chapter 5", completed: false, youtubeId: "frGXQHyQu00", durationMins: 30 }
      ]
    },
    {
      id: "geography-9",
      name: "Geography",
      description: "Understand India's size, coordinate locations, physical drainage, and wildlife vegetation.",
      icon: "BookOpen",
      progressPercent: 35,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "g9-c1", title: "India – Size and Location", unit: "Chapter 1", completed: false, youtubeId: "2wX5l1ksFr8", durationMins: 18 },
        { id: "g9-c2", title: "Physical Features of India", unit: "Chapter 2", completed: false, youtubeId: "qsxmV-9ut6E", durationMins: 25 },
        { id: "g9-c3", title: "Drainage", unit: "Chapter 3", completed: false, youtubeId: "7-4UgkKHm-g", durationMins: 20 },
        { id: "g9-c4", title: "Climate", unit: "Chapter 4", completed: false, youtubeId: "sYao9OWPsx4", durationMins: 22 },
        { id: "g9-c5", title: "Natural Vegetation and Wildlife", unit: "Chapter 5", completed: false, youtubeId: "5pTuEzq1fQU", durationMins: 24 }
      ]
    }
  ],
  "Class 10": [
    {
      id: "math-10",
      name: "Mathematics",
      description: "Advance to complex real numbers, quadratic algebra, equations system, and progressions.",
      icon: "Calculator",
      progressPercent: 55,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "m10-c1", title: "Real Numbers", unit: "Chapter 1", completed: true, youtubeId: "-UdHmSTmQtw", durationMins: 30 },
        { id: "m10-c2", title: "Polynomials", unit: "Chapter 2", completed: false, youtubeId: "Hnoe8hNPFr8", durationMins: 28 },
        { id: "m10-c3", title: "Pair of Linear Equations in Two Variables", unit: "Chapter 3", completed: false, youtubeId: "p_yr53bhesU", durationMins: 32 },
        { id: "m10-c4", title: "Quadratic Equations", unit: "Chapter 4", completed: false, youtubeId: "t8fUmrKnvEM", durationMins: 35 },
        { id: "m10-c5", title: "Arithmetic Progressions", unit: "Chapter 5", completed: false, youtubeId: "zPKdZKBG4oQ", durationMins: 34 }
      ]
    },
    {
      id: "science-10",
      name: "Science",
      description: "In-depth explorations of reactions, carbon chains, acids-bases, and vital life cycles.",
      icon: "FlaskConical",
      progressPercent: 60,
      colorClass: "bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-300 border-emerald-200 dark:border-emerald-900",
      accentColor: "emerald",
      chapters: [
        { id: "s10-c1", title: "Chemical Reactions and Equations", unit: "Chapter 1", completed: true, youtubeId: "gQ-X9wV8TXQ", durationMins: 28 },
        { id: "s10-c2", title: "Acids, Bases and Salts", unit: "Chapter 2", completed: false, youtubeId: "7k2rs5yGOFM", durationMins: 32 },
        { id: "s10-c3", title: "Metals and Non-Metals", unit: "Chapter 3", completed: false, youtubeId: "YV1BFWi-AWY", durationMins: 30 },
        { id: "s10-c4", title: "Carbon and Its Compounds", unit: "Chapter 4", completed: false, youtubeId: "Ff0t3zTzgR8", durationMins: 35 },
        { id: "s10-c5", title: "Life Processes", unit: "Chapter 5", completed: false, youtubeId: "2anxgj0TUgQ", durationMins: 34 }
      ]
    },
    {
      id: "english-10",
      name: "English",
      description: "The classic Letter to God, Nelson Mandela's walk, and deep journal records.",
      icon: "BookOpen",
      progressPercent: 40,
      colorClass: "bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-300 border-amber-200 dark:border-amber-900",
      accentColor: "amber",
      chapters: [
        { id: "e10-c1", title: "A Letter to God", unit: "Chapter 1", completed: true, youtubeId: "TgqwVI0AE_o", durationMins: 15 },
        { id: "e10-c2", title: "Nelson Mandela: Long Walk to Freedom", unit: "Chapter 2", completed: false, youtubeId: "UXpLYES-n3o", durationMins: 22 },
        { id: "e10-c3", title: "Two Stories about Flying", unit: "Chapter 3", completed: false, youtubeId: "FLo1w0TjQ_E", durationMins: 18 },
        { id: "e10-c4", title: "From the Diary of Anne Frank", unit: "Chapter 4", completed: false, youtubeId: "dN8T8bO-CnI", durationMins: 20 },
        { id: "e10-c5", title: "The Hundred Dresses – I", unit: "Chapter 5", completed: false, youtubeId: "ab23svjBwdQ", durationMins: 18 }
      ]
    },
    {
      id: "history-10",
      name: "History",
      description: "Nationalism across Europe and India, world globalisation, and industrial age.",
      icon: "History",
      progressPercent: 30,
      colorClass: "bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-300 border-purple-200 dark:border-purple-900",
      accentColor: "purple",
      chapters: [
        { id: "h10-c1", title: "The Rise of Nationalism in Europe", unit: "Chapter 1", completed: true, youtubeId: "_6z3ao16NVM", durationMins: 30 },
        { id: "h10-c2", title: "Nationalism in India", unit: "Chapter 2", completed: false, youtubeId: "n96yn8IfE-4", durationMins: 35 },
        { id: "h10-c3", title: "The Making of a Global World", unit: "Chapter 3", completed: false, youtubeId: "QXHtptFKVm8", durationMins: 32 },
        { id: "h10-c4", title: "The Age of Industrialisation", unit: "Chapter 4", completed: false, youtubeId: "9XWKDo5LElU", durationMins: 30 },
        { id: "h10-c5", title: "Print Culture and the Modern World", unit: "Chapter 5", completed: false, youtubeId: "8osoP6PNtoQ", durationMins: 28 }
      ]
    },
    {
      id: "geography-10",
      name: "Geography",
      description: "Explore forest wealth, wildlife, water security, agriculture, and minerals.",
      icon: "BookOpen",
      progressPercent: 40,
      colorClass: "bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 border-blue-200 dark:border-blue-900",
      accentColor: "blue",
      chapters: [
        { id: "g10-c1", title: "Resources and Development", unit: "Chapter 1", completed: false, youtubeId: "czJ1qAusGa8", durationMins: 20 },
        { id: "g10-c2", title: "Forest and Wildlife Resources", unit: "Chapter 2", completed: false, youtubeId: "AlVlV3BPy_Y", durationMins: 18 },
        { id: "g10-c3", title: "Water Resources", unit: "Chapter 3", completed: false, youtubeId: "kEhVWVCeUTk", durationMins: 22 },
        { id: "g10-c4", title: "Agriculture", unit: "Chapter 4", completed: false, youtubeId: "VgJ-zRAdvaE", durationMins: 20 },
        { id: "g10-c5", title: "Minerals and Energy Resources", unit: "Chapter 5", completed: false, youtubeId: "zaiju4KFOPg", durationMins: 24 }
      ]
    }
  ]
};

export const DEFAULT_REVISION_NOTE = `## Polynomials Revision Guide & Cheat Sheet
### Class 8th CBSE Advanced Mathematics

***

### 1. Introduction to Polynomials
A **polynomial** is an algebraic expression consisting of variables, coefficients, and exponents, which are combined using addition, subtraction, multiplication, and non-negative integer exponents.

* **General Form:** $a_n x^n + a_{n-1} x^{n-1} + ... + a_1 x + a_0$
* **Terms:** Parts of the polynomial separated by $+$ or $-$ signs.
* **Degree:** The highest power of the variable present in the polynomial.

***

### 2. Classification of Polynomials
Polynomials can be classified based on the number of terms or their degree:

#### A. By Number of Terms
* **Monomial:** Exactly 1 term. (e.g., $3x$, $-5y^2$, $12$)
* **Binomial:** Exactly 2 terms. (e.g., $2x + 5$, $y^2 - 9$)
* **Trinomial:** Exactly 3 terms. (e.g., $x^2 + 5x + 6$)

#### B. By Degree
* **Linear (Degree 1):** $ax + b$
* **Quadratic (Degree 2):** $ax^2 + bx + c$
* **Cubic (Degree 3):** $ax^3 + bx^2 + cx + d$

***

### 3. Key Operations & Identities
When working with algebraic polynomials, three identities are absolutely essential to memorize:

1. **Identity I:** $(a + b)^2 = a^2 + 2ab + b^2$
2. **Identity II:** $(a - b)^2 = a^2 - 2ab + b^2$
3. **Identity III:** $(a + b)(a - b) = a^2 - b^2$

***

### 4. Mnemonic for Identities
Remember **S-D-P (Square, Double, Product)** for squaring binomials:
* **S**quare the first term.
* **D**ouble the **P**roduct of the two terms.
* **S**quare the last term.

***

### 5. Common Traps & Pitfalls to Avoid
* **Trap 1:** Writing $(a + b)^2 = a^2 + b^2$. 
  * *Correction:* Never forget the middle term ($2ab$)! $(a+b)^2 = a^2 + 2ab + b^2$.
* **Trap 2:** Negative signs during distribution.
  * *Correction:* $-3(x - 2)$ expands to $-3x + 6$, not $-3x - 6$!`;
