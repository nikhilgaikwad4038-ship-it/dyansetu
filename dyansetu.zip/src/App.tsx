import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import logoImage from "../image/WhatsApp Image 2026-06-29 at 12.43.16 PM.jpeg";
import brandTextImage from "../image/WhatsApp Image 2026-06-29 at 12.43.16 PM (1).jpeg";
import {
  School,
  LayoutDashboard,
  BookOpen,
  Video,
  Award,
  HelpCircle,
  Settings,
  Search,
  Moon,
  Sun,
  ChevronRight,
  ChevronLeft,
  Play,
  Check,
  Bolt,
  Trophy,
  Sparkles,
  Brain,
  Clock,
  MessageSquare,
  Send,
  RefreshCw,
  FileText,
  Calculator,
  FlaskConical,
  Plus,
  Trash2,
  Menu,
  X,
  ArrowRight,
  Volume2,
  Bookmark,
  Calendar,
  Cloud,
  CloudOff,
  Database,
  Lock,
  Mail,
  ExternalLink,
} from "lucide-react";
import { CLASS_CURRICULUM, DEFAULT_REVISION_NOTE } from "./data";
import { getInteractiveSlides } from "./utils/interactiveSlides";
import {
  Subject,
  VideoLecture,
  QuizQuestion,
  ChatMessage,
  SavedNote,
  QuizScoreHistory,
  ActiveTab,
} from "./types";
import {
  auth,
  db,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User,
} from "./firebase";
import {
  doc,
  setDoc,
  getDoc,
  collection,
  query,
  where,
  getDocs,
} from "firebase/firestore";

export default function App() {
  // Navigation & UI Layout State
  const [activeTab, setActiveTab] = useState<ActiveTab>("dashboard");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // Student Profile State (1st class to 10th class)
  const [profileName, setProfileName] = useState(() => {
    return localStorage.getItem("ds_profile_name") || "Aryan Sharma";
  });
  const [profileClass, setProfileClass] = useState(() => {
    return localStorage.getItem("ds_profile_class") || "Class 8";
  });
  const [profileBoard, setProfileBoard] = useState(() => {
    return localStorage.getItem("ds_profile_board") || "CBSE";
  });

  // Subjects & Chapter Completion State - dynamically populated per active grade class
  const [subjects, setSubjects] = useState<Subject[]>([]);

  // Active Subject Detail Selector (for syllabus browser)
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);

  // Quick Video Player State
  const [activeVideo, setActiveVideo] = useState<{
    title: string;
    subject: string;
    chapter: string;
    youtubeId: string;
    playlistIndex?: number;
    durationMins: number;
  } | null>(null);

  const [playerMode, setPlayerMode] = useState<"youtube" | "interactive">("youtube");
  const [activeSlideIndex, setActiveSlideIndex] = useState(0);

  // Saved Notes and Quiz History States
  const [savedNotes, setSavedNotes] = useState<SavedNote[]>(() => {
    const saved = localStorage.getItem("ds_saved_notes");
    return saved ? JSON.parse(saved) : [];
  });
  
  const [quizHistory, setQuizHistory] = useState<QuizScoreHistory[]>(() => {
    const saved = localStorage.getItem("ds_quiz_history");
    return saved ? JSON.parse(saved) : [
      {
        id: "h-init-1",
        quizTitle: "Algebra Challenge",
        subject: "Mathematics",
        score: 4,
        totalQuestions: 5,
        date: new Date(Date.now() - 86400000 * 2).toISOString(),
      },
    ];
  });

  // AI Quiz Workspace State
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizError, setQuizError] = useState("");
  const [activeQuiz, setActiveQuiz] = useState<{
    title: string;
    subject: string;
    questions: QuizQuestion[];
  } | null>(null);
  const [quizState, setQuizState] = useState({
    currentIndex: 0,
    selectedOption: null as number | null,
    answers: [] as number[],
    isSubmitted: false,
    score: 0,
    showFinalResults: false,
  });

  // Custom Quiz Generator Parameters
  const [quizSubject, setQuizSubject] = useState("Mathematics");
  const [quizTopic, setQuizTopic] = useState("");

  // AI Revision Notes Generator State
  const [notesLoading, setNotesLoading] = useState(false);
  const [notesError, setNotesError] = useState("");
  const [generatedNotes, setGeneratedNotes] = useState<{
    topic: string;
    subject: string;
    markdown: string;
  } | null>(null);

  // AI Tutor Main Chat Interface State
  const [tutorMessages, setTutorMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem("ds_tutor_messages");
    return saved ? JSON.parse(saved) : [
      {
        id: "msg-1",
        role: "model",
        text: "Hi Aryan! 👋 I'm DyanSetu AI, your free 1-on-1 personalized academic tutor. I'm ready to help you learn your syllabus today! Ask me any question, request a chapter recap, or generate a practice quiz.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);

  // Monthly Calendar and Completed Chapters Dates State
  const [completedDates, setCompletedDates] = useState<string[]>(() => {
    const saved = localStorage.getItem("ds_completed_dates");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    // Default realistic past completed dates matching study streak
    return [
      "2026-06-15",
      "2026-06-18",
      "2026-06-20",
      "2026-06-22",
      "2026-06-23",
      "2026-06-24",
      "2026-06-25",
      "2026-06-26",
      "2026-06-27",
      "2026-06-28",
      "2026-06-29",
      "2026-06-30"
    ];
  });

  useEffect(() => {
    localStorage.setItem("ds_completed_dates", JSON.stringify(completedDates));
  }, [completedDates]);

  // Firebase Auth and Cloud Sync states
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isGuest, setIsGuest] = useState(() => {
    return localStorage.getItem("ds_is_guest") === "true";
  });
  const [sessionToken, setSessionToken] = useState<string | null>(() => {
    return localStorage.getItem("ds_session_token");
  });
  const [userEmail, setUserEmail] = useState<string | null>(() => {
    return localStorage.getItem("ds_user_email");
  });
  
  // Auth Form State
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [authSuccess, setAuthSuccess] = useState("");
  const [authLoading, setAuthLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<string | null>(() => {
    return localStorage.getItem("ds_last_synced_time");
  });

  // Watch Authentication State and synchronize Firestore content dynamically
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        setIsGuest(false);
        localStorage.setItem("ds_is_guest", "false");
        setSessionToken(user.uid);
        setUserEmail(user.email);
        localStorage.setItem("ds_session_token", user.uid);
        localStorage.setItem("ds_user_email", user.email || "");

        // Load profile
        try {
          const userDocRef = doc(db, "users", user.uid);
          const userDoc = await getDoc(userDocRef);
          if (userDoc.exists()) {
            const data = userDoc.data();
            if (data.name) {
              setProfileName(data.name);
              localStorage.setItem("ds_profile_name", data.name);
            }
            if (data.class) {
              setProfileClass(data.class);
              localStorage.setItem("ds_profile_class", data.class);
            }
            if (data.board) {
              setProfileBoard(data.board);
              localStorage.setItem("ds_profile_board", data.board);
            }
          } else {
            // Write profile
            const profileData = {
              uid: user.uid,
              name: user.displayName || profileName || "Aryan Sharma",
              email: user.email || "",
              class: profileClass,
              board: profileBoard,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            await setDoc(userDocRef, profileData);
          }

          // Pull saved notes from Firestore
          const notesQuery = query(collection(db, "savedNotes"), where("userId", "==", user.uid));
          const notesSnap = await getDocs(notesQuery);
          const notesList: SavedNote[] = [];
          notesSnap.forEach((docSnap) => {
            const d = docSnap.data();
            notesList.push({
              id: d.id,
              topic: d.topic,
              subject: d.subject,
              notesMarkdown: d.notesMarkdown,
              createdAt: d.createdAt
            });
          });
          if (notesList.length > 0) {
            setSavedNotes(notesList);
          }

          // Pull quiz history
          const quizQuery = query(collection(db, "quizHistory"), where("userId", "==", user.uid));
          const quizSnap = await getDocs(quizQuery);
          const quizList: QuizScoreHistory[] = [];
          quizSnap.forEach((docSnap) => {
            const d = docSnap.data();
            quizList.push({
              id: d.id,
              quizTitle: d.quizTitle,
              subject: d.subject,
              score: d.score,
              totalQuestions: d.totalQuestions,
              date: d.date
            });
          });
          if (quizList.length > 0) {
            setQuizHistory(quizList);
          }

          // Pull completed chapters log
          const compQuery = query(collection(db, "completedChapters"), where("userId", "==", user.uid));
          const compSnap = await getDocs(compQuery);
          const completedDatesSet = new Set<string>(completedDates);
          compSnap.forEach((docSnap) => {
            const d = docSnap.data();
            if (d.completed && d.completedAt) {
              completedDatesSet.add(d.completedAt);
            }
          });
          const mergedDates = Array.from(completedDatesSet);
          setCompletedDates(mergedDates);

          const timestamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
          setLastSyncedTime(timestamp);
          localStorage.setItem("ds_last_synced_time", timestamp);
        } catch (err: any) {
          if (err instanceof Error && err.message.includes("offline")) {
            console.warn("Firestore initialization sync offline (using local cache):", err.message);
          } else {
            console.error("Firestore initialization sync error:", err);
          }
        }
      } else {
        setSessionToken(null);
        localStorage.removeItem("ds_session_token");
        localStorage.removeItem("ds_user_email");
      }
    });
    return () => unsubscribe();
  }, []);

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError("");
    setAuthSuccess("");
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, authEmail, authPassword);
      const user = userCredential.user;
      
      // Save profile immediately in Firestore
      const userDocRef = doc(db, "users", user.uid);
      await setDoc(userDocRef, {
        uid: user.uid,
        name: profileName,
        email: authEmail,
        class: profileClass,
        board: profileBoard,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });

      setAuthSuccess("Account successfully created!");
      setIsGuest(false);
      localStorage.setItem("ds_is_guest", "false");
      setAuthEmail("");
      setAuthPassword("");
    } catch (err: any) {
      let friendlyMessage = err.message || "An unexpected error occurred during signup.";
      if (err.code === "auth/email-already-in-use") {
        friendlyMessage = "This email is already registered. Please sign in instead.";
      } else if (err.code === "auth/weak-password") {
        friendlyMessage = "Password must be at least 6 characters long.";
      } else if (err.code === "auth/invalid-email") {
        friendlyMessage = "Please enter a valid email address.";
      }
      setAuthError(friendlyMessage);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError("");
    setAuthSuccess("");
    try {
      await signInWithEmailAndPassword(auth, authEmail, authPassword);
      setAuthSuccess("Successfully logged in!");
      setIsGuest(false);
      localStorage.setItem("ds_is_guest", "false");
      setAuthEmail("");
      setAuthPassword("");
    } catch (err: any) {
      let friendlyMessage = err.message || "Invalid credentials. Please try again.";
      if (err.code === "auth/user-not-found" || err.code === "auth/wrong-password" || err.code === "auth/invalid-credential") {
        friendlyMessage = "Incorrect email or password. Please verify and retry.";
      } else if (err.code === "auth/invalid-email") {
        friendlyMessage = "Please enter a valid email address.";
      }
      setAuthError(friendlyMessage);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setAuthLoading(true);
    setAuthError("");
    setAuthSuccess("");
    try {
      await signInWithPopup(auth, googleProvider);
      setAuthSuccess("Successfully signed in with Google!");
      setIsGuest(false);
      localStorage.setItem("ds_is_guest", "false");
    } catch (err: any) {
      console.error("Google sign in error:", err);
      let friendlyMessage = err.message || "Google sign-in was cancelled or blocked.";
      if (err.code === "auth/popup-blocked") {
        friendlyMessage = "Sign-in popup was blocked by your browser. Please allow popups or use the email/password form.";
      } else if (err.code === "auth/popup-closed-by-user") {
        friendlyMessage = "Sign-in popup was closed before completion.";
      }
      setAuthError(friendlyMessage);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogOut = async () => {
    try {
      await signOut(auth);
      setProfileName("Aryan Sharma");
      setProfileClass("Class 8");
      setProfileBoard("CBSE");
      setSavedNotes([]);
      setQuizHistory([]);
      setIsGuest(false);
      localStorage.setItem("ds_is_guest", "false");
      localStorage.removeItem("ds_session_token");
      localStorage.removeItem("ds_user_email");
      localStorage.removeItem("ds_last_synced_time");
      setSessionToken(null);
      setUserEmail(null);
      setLastSyncedTime(null);
      setAuthSuccess("Signed out successfully.");
      setTimeout(() => setAuthSuccess(""), 3000);
    } catch (e: any) {
      console.error("Logout error:", e);
    }
  };

  const syncWithFirebase = async () => {
    if (!currentUser) return;
    setIsSyncing(true);
    try {
      // Sync user profile
      const userDocRef = doc(db, "users", currentUser.uid);
      await setDoc(userDocRef, {
        uid: currentUser.uid,
        name: profileName,
        email: currentUser.email || "",
        class: profileClass,
        board: profileBoard,
        updatedAt: new Date().toISOString(),
      }, { merge: true });

      // Backup notes
      for (const note of savedNotes) {
        await setDoc(doc(db, "savedNotes", note.id), {
          id: note.id,
          userId: currentUser.uid,
          topic: note.topic,
          subject: note.subject,
          notesMarkdown: note.notesMarkdown,
          createdAt: note.createdAt
        });
      }

      // Backup quiz history
      for (const hist of quizHistory) {
        await setDoc(doc(db, "quizHistory", hist.id), {
          id: hist.id,
          userId: currentUser.uid,
          quizTitle: hist.quizTitle,
          subject: hist.subject,
          score: hist.score,
          totalQuestions: hist.totalQuestions,
          date: hist.date
        });
      }

      // Backup completed chapters log
      for (const dateStr of completedDates) {
        await setDoc(doc(db, "completedChapters", `log-${currentUser.uid}-${dateStr}`), {
          id: `log-${currentUser.uid}-${dateStr}`,
          userId: currentUser.uid,
          completed: true,
          completedAt: dateStr
        });
      }

      const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setLastSyncedTime(timestamp);
      localStorage.setItem("ds_last_synced_time", timestamp);
    } catch (err) {
      console.error("Auto Sync Error:", err);
    } finally {
      setIsSyncing(false);
    }
  };

  // Auto-sync when subjects, completion state, notes or profile updates
  useEffect(() => {
    if (currentUser) {
      const timer = setTimeout(() => {
        syncWithFirebase();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [profileName, profileClass, profileBoard, savedNotes, quizHistory, completedDates]);

  // Monthly Calendar and Completed Chapters Dates State
  const [calendarDate, setCalendarDate] = useState(() => {
    const d = new Date();
    return { year: d.getFullYear(), month: d.getMonth() };
  });

  const handlePrevMonth = () => {
    setCalendarDate((prev) => {
      let newMonth = prev.month - 1;
      let newYear = prev.year;
      if (newMonth < 0) {
        newMonth = 11;
        newYear -= 1;
      }
      return { year: newYear, month: newMonth };
    });
  };

  const handleNextMonth = () => {
    setCalendarDate((prev) => {
      let newMonth = prev.month + 1;
      let newYear = prev.year;
      if (newMonth > 11) {
        newMonth = 0;
        newYear += 1;
      }
      return { year: newYear, month: newMonth };
    });
  };

  const MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  // UI Refs for scrolling chat
  const mainChatEndRef = useRef<HTMLDivElement>(null);

  // Load subject progress for the current grade from localStorage, or fall back to default curriculum
  useEffect(() => {
    const storageKey = `ds_subjects_grade_${profileClass.replace(/\s+/g, "_")}`;
    const saved = localStorage.getItem(storageKey);
    const defaults = CLASS_CURRICULUM[profileClass] || CLASS_CURRICULUM["Class 8"];
    if (saved) {
      try {
        let parsed = JSON.parse(saved) as Subject[];
        let hasChanges = false;
        
        // Merge missing subjects or update chapter links dynamically from CLASS_CURRICULUM defaults
        const merged: Subject[] = [];
        defaults.forEach((defSub) => {
          const existingSub = parsed.find((s) => s.id === defSub.id);
          if (!existingSub) {
            merged.push(defSub);
            hasChanges = true;
          } else {
            const mergedChapters = [...existingSub.chapters];
            defSub.chapters.forEach((defChap) => {
              const existingChapIdx = mergedChapters.findIndex((c) => c.id === defChap.id);
              if (existingChapIdx === -1) {
                mergedChapters.push(defChap);
                hasChanges = true;
              } else {
                const existingChap = mergedChapters[existingChapIdx];
                if (existingChap.youtubeId !== defChap.youtubeId || existingChap.title !== defChap.title) {
                  mergedChapters[existingChapIdx] = {
                    ...existingChap,
                    youtubeId: defChap.youtubeId,
                    title: defChap.title,
                    durationMins: defChap.durationMins,
                    playlistIndex: defChap.playlistIndex,
                  };
                  hasChanges = true;
                }
              }
            });
            merged.push({
              ...existingSub,
              chapters: mergedChapters,
            });
          }
        });

        // Also check if any obsolete subjects should be retained/cleaned up (optional, let's keep merged)
        const finalSubjects = hasChanges ? merged : parsed;
        if (hasChanges) {
          localStorage.setItem(storageKey, JSON.stringify(finalSubjects));
        }

        setSubjects(finalSubjects);
        // Sync active syllabus selection
        if (selectedSubject) {
          const fresh = finalSubjects.find((s: Subject) => s.id === selectedSubject.id);
          if (fresh) setSelectedSubject(fresh);
        }
      } catch (e) {
        setSubjects(defaults);
      }
    } else {
      setSubjects(defaults);
    }
  }, [profileClass]);

  // Persist current subject progress back into local storage when modified
  const saveSubjectProgress = (updatedSubjects: Subject[]) => {
    setSubjects(updatedSubjects);
    const storageKey = `ds_subjects_grade_${profileClass.replace(/\s+/g, "_")}`;
    localStorage.setItem(storageKey, JSON.stringify(updatedSubjects));
  };

  // Synchronize student profile attributes
  useEffect(() => {
    localStorage.setItem("ds_profile_name", profileName);
    localStorage.setItem("ds_profile_class", profileClass);
    localStorage.setItem("ds_profile_board", profileBoard);
  }, [profileName, profileClass, profileBoard]);

  useEffect(() => {
    localStorage.setItem("ds_saved_notes", JSON.stringify(savedNotes));
  }, [savedNotes]);

  useEffect(() => {
    localStorage.setItem("ds_quiz_history", JSON.stringify(quizHistory));
  }, [quizHistory]);

  useEffect(() => {
    localStorage.setItem("ds_tutor_messages", JSON.stringify(tutorMessages));
  }, [tutorMessages]);

  // Dark Mode support
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);

  // Scroll to bottom of tutor chat
  useEffect(() => {
    mainChatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [tutorMessages, chatLoading]);

  // Handle dropdown selection to instantly change class
  const handleClassChange = (newClass: string) => {
    setProfileClass(newClass);
    // Reset selected active subject so it loads fresh for the new class
    setSelectedSubject(null);
    // Auto post dynamic greeting from DyanSetu AI on class switch
    const gradeGreet: ChatMessage = {
      id: `msg-grade-${Date.now()}`,
      role: "model",
      text: `Excellent! You've switched your focus to **${newClass}**. I've adjusted your study library, practice quizzes, and curriculum modules instantly. Let's make learning awesome! 🚀`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setTutorMessages((prev) => [...prev, gradeGreet]);
  };

  // Handle navigating to Dashboard cleanly, resetting any sub-page/viewer states
  const handleGoToDashboard = () => {
    setActiveTab("dashboard");
    setIsSidebarOpen(false);
    setActiveVideo(null);
    setSelectedSubject(null);
  };

  // Toggle chapter completion checkbox and compute new percentage progress
  const handleToggleChapter = (subjectId: string, chapterId: string) => {
    let wasMarkedCompleted = false;
    const updated = subjects.map((sub) => {
      if (sub.id === subjectId) {
        const updatedChapters = sub.chapters.map((chap) => {
          if (chap.id === chapterId) {
            const nextCompleted = !chap.completed;
            wasMarkedCompleted = nextCompleted;
            return { ...chap, completed: nextCompleted };
          }
          return chap;
        });
        const completedCount = updatedChapters.filter((c) => c.completed).length;
        const progressPercent = Math.round((completedCount / updatedChapters.length) * 100);
        return { ...sub, chapters: updatedChapters, progressPercent };
      }
      return sub;
    });
    saveSubjectProgress(updated);

    const todayStr = new Date().toISOString().split("T")[0];
    if (wasMarkedCompleted) {
      setCompletedDates((prev) => {
        if (prev.includes(todayStr)) return prev;
        return [...prev, todayStr];
      });
    } else {
      const anyCompleted = updated.some((sub) =>
        sub.chapters.some((chap) => chap.completed)
      );
      if (!anyCompleted) {
        setCompletedDates((prev) => prev.filter((d) => d !== todayStr));
      }
    }
  };

  // Calculate total aggregate progress percentage across all subjects in the selected class
  const getAggregateProgress = () => {
    if (subjects.length === 0) return 0;
    const totalChapters = subjects.reduce((sum, sub) => sum + sub.chapters.length, 0);
    const completedChapters = subjects.reduce(
      (sum, sub) => sum + sub.chapters.filter((c) => c.completed).length,
      0
    );
    return totalChapters > 0 ? Math.round((completedChapters / totalChapters) * 100) : 0;
  };

  // Helper: custom markdown renderer with clean styles and highlights
  const renderMarkdown = (text: string) => {
    if (!text) return null;
    return text.split("\n").map((line, i) => {
      if (line.startsWith("### ")) {
        return (
          <h3 key={i} className="text-base md:text-lg font-bold text-slate-800 dark:text-slate-100 mt-4 mb-2">
            {line.replace("### ", "")}
          </h3>
        );
      }
      if (line.startsWith("## ")) {
        return (
          <h2 key={i} className="text-lg md:text-xl font-extrabold text-blue-600 dark:text-blue-400 mt-6 mb-3 border-b border-slate-150 dark:border-slate-800 pb-1">
            {line.replace("## ", "")}
          </h2>
        );
      }
      if (line.startsWith("# ")) {
        return (
          <h1 key={i} className="text-xl md:text-2xl font-black text-slate-950 dark:text-white mt-6 mb-4">
            {line.replace("# ", "")}
          </h1>
        );
      }
      if (line.startsWith("* ") || line.startsWith("- ")) {
        return (
          <li key={i} className="list-disc ml-5 text-slate-600 dark:text-slate-300 my-1 text-sm md:text-base">
            {line.substring(2)}
          </li>
        );
      }
      if (line.trim() === "***" || line.trim() === "---") {
        return <hr key={i} className="my-4 border-slate-200 dark:border-slate-800" />;
      }
      if (line.trim() === "") {
        return <div key={i} className="h-2" />;
      }

      let content: React.ReactNode[] = [line];
      if (line.includes("**")) {
        const parts = line.split("**");
        content = parts.map((part, index) =>
          index % 2 === 1 ? (
            <strong key={index} className="font-bold text-slate-900 dark:text-white">
              {part}
            </strong>
          ) : (
            part
          )
        );
      }
      return (
        <p key={i} className="text-sm md:text-base text-slate-600 dark:text-slate-300 leading-relaxed my-1.5">
          {content}
        </p>
      );
    });
  };

  // Dynamic Lucide Icon mapping
  const renderSubjectIcon = (iconName: string, className = "w-6 h-6") => {
    switch (iconName) {
      case "Calculator":
        return <Calculator className={className} />;
      case "FlaskConical":
        return <FlaskConical className={className} />;
      case "BookOpen":
        return <BookOpen className={className} />;
      case "History":
        return <Award className={className} />;
      default:
        return <BookOpen className={className} />;
    }
  };

  // --- INTERACTIVE APIS TO SERVER ---

  // Tutor AI Chat message dispatching
  const handleSendTutorMessage = async (text: string) => {
    if (!text.trim() || chatLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: "user",
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setTutorMessages((prev) => [...prev, userMsg]);
    setChatInput("");
    setChatLoading(true);

    try {
      const historyPayload = tutorMessages.map((m) => ({
        role: m.role === "user" ? "user" : "model",
        text: m.text,
      }));

      const res = await fetch("/api/tutor/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: historyPayload,
          contextSubject: selectedSubject ? `${profileClass} ${selectedSubject.name}` : profileClass,
        }),
      });

      if (!res.ok) {
        throw new Error("Tutor backend failed to respond");
      }

      const data = await res.json();
      const modelMsg: ChatMessage = {
        id: `msg-${Date.now()}-model`,
        role: "model",
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setTutorMessages((prev) => [...prev, modelMsg]);
    } catch (err: any) {
      console.error(err);
      setTutorMessages((prev) => [
        ...prev,
        {
          id: `msg-${Date.now()}-error`,
          role: "model",
          text: `I had a slight hiccup connecting with my central server. Please ensure your GEMINI_API_KEY secret is defined. Details: ${err.message}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  // AI Quiz Zone generation
  const handleGenerateAIQuiz = async (subjectName: string, topicName: string) => {
    setActiveTab("quiz");
    setQuizLoading(true);
    setQuizError("");
    setActiveQuiz(null);

    try {
      const res = await fetch("/api/tutor/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject: `${profileClass} ${subjectName}`, topic: topicName }),
      });

      if (!res.ok) {
        throw new Error("Could not connect to generator engine");
      }

      const quizData = await res.json();
      if (!quizData.questions || quizData.questions.length === 0) {
        throw new Error("Incomplete quiz scheme received from model.");
      }

      setActiveQuiz({
        title: quizData.title || `${subjectName} Chapter Challenge`,
        subject: subjectName,
        questions: quizData.questions,
      });

      setQuizState({
        currentIndex: 0,
        selectedOption: null,
        answers: [],
        isSubmitted: false,
        score: 0,
        showFinalResults: false,
      });
    } catch (err: any) {
      console.error(err);
      setQuizError(
        `Failed to launch quiz: ${err.message}. Ensure your GEMINI_API_KEY is linked in settings.`
      );
    } finally {
      setQuizLoading(false);
    }
  };

  // AI Revision Note/Cheat Sheet creator
  const handleGenerateRevisionNotes = async (subjectName: string, topicName: string) => {
    setActiveTab("library");
    setNotesLoading(true);
    setNotesError("");
    setGeneratedNotes(null);

    try {
      const res = await fetch("/api/tutor/generate-notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject: `${profileClass} ${subjectName}`, topic: topicName }),
      });

      if (!res.ok) throw new Error("Server error during cheat-sheet compilation");

      const data = await res.json();
      const noteToSave: SavedNote = {
        id: `note-${Date.now()}`,
        topic: topicName,
        subject: subjectName,
        notesMarkdown: data.notes,
        createdAt: new Date().toLocaleDateString(),
      };
      setSavedNotes((prev) => [noteToSave, ...prev]);
      setGeneratedNotes({
        topic: topicName,
        subject: subjectName,
        markdown: data.notes,
      });
    } catch (err: any) {
      console.error(err);
      setNotesError(`Unable to write cheat sheet: ${err.message}. Ensure GEMINI_API_KEY is set.`);
    } finally {
      setNotesLoading(false);
    }
  };

  // Answer selection in quiz
  const handleQuizOptionSelect = (index: number) => {
    if (quizState.isSubmitted) return;
    setQuizState((prev) => ({ ...prev, selectedOption: index }));
  };

  const handleQuizSubmitAnswer = () => {
    if (quizState.selectedOption === null || quizState.isSubmitted) return;
    const currentQuestion = activeQuiz!.questions[quizState.currentIndex];
    const isCorrect = quizState.selectedOption === currentQuestion.correctOptionIndex;

    setQuizState((prev) => ({
      ...prev,
      isSubmitted: true,
      score: isCorrect ? prev.score + 1 : prev.score,
      answers: [...prev.answers, prev.selectedOption!],
    }));
  };

  const handleQuizNextQuestion = () => {
    if (quizState.currentIndex < activeQuiz!.questions.length - 1) {
      setQuizState((prev) => ({
        ...prev,
        currentIndex: prev.currentIndex + 1,
        selectedOption: null,
        isSubmitted: false,
      }));
    } else {
      // Complete & Save record
      setQuizState((prev) => ({ ...prev, showFinalResults: true }));
      const hist: QuizScoreHistory = {
        id: `q-hist-${Date.now()}`,
        quizTitle: activeQuiz!.title,
        subject: activeQuiz!.subject,
        score: quizState.score,
        totalQuestions: activeQuiz!.questions.length,
        date: new Date().toISOString(),
      };
      setQuizHistory((prev) => [hist, ...prev]);
    }
  };

  // Handle launch of a video lecture card
  const handleLaunchVideo = (title: string, subject: string, chapter: string, youtubeId: string, durationMins: number, playlistIndex?: number) => {
    setActiveVideo({ title, subject, chapter, youtubeId, durationMins, playlistIndex });
    setActiveSlideIndex(0);
    // Scroll to the video view
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Filter content for quick search box
  const getFilteredItems = () => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    const result: { type: "chapter" | "subject" | "video"; title: string; subtitle: string; action: () => void }[] = [];

    subjects.forEach((sub) => {
      if (sub.name.toLowerCase().includes(query)) {
        result.push({
          type: "subject",
          title: sub.name,
          subtitle: `${profileClass} • Study Syllabus`,
          action: () => {
            setSelectedSubject(sub);
            setActiveTab("subjects");
            setSearchQuery("");
          },
        });
      }

      sub.chapters.forEach((chap) => {
        if (chap.title.toLowerCase().includes(query)) {
          result.push({
            type: "chapter",
            title: chap.title,
            subtitle: `${sub.name} • ${chap.unit}`,
            action: () => {
              setSelectedSubject(sub);
              setActiveTab("subjects");
              setSearchQuery("");
            },
          });
        }
      });
    });

    return result.slice(0, 5);
  };

  const searchResults = getFilteredItems();

  // Derived state for the monthly calendar view
  const getCalendarGrid = () => {
    const { year, month } = calendarDate;
    const firstDayIndex = new Date(year, month, 1).getDay();
    // Monday-first grid: if firstDayIndex is 0 (Sunday), make it index 6. Else subtract 1.
    const startingDay = firstDayIndex === 0 ? 6 : firstDayIndex - 1;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevDaysInMonth = new Date(year, month, 0).getDate();
    
    const cells = [];
    
    // Previous month filler days
    for (let i = startingDay - 1; i >= 0; i--) {
      cells.push({
        dayNum: prevDaysInMonth - i,
        isCurrentMonth: false,
        dateStr: ""
      });
    }
    
    // Current month days
    for (let i = 1; i <= daysInMonth; i++) {
      const monthStr = String(month + 1).padStart(2, "0");
      const dayStr = String(i).padStart(2, "0");
      const dateStr = `${year}-${monthStr}-${dayStr}`;
      cells.push({
        dayNum: i,
        isCurrentMonth: true,
        dateStr
      });
    }
    
    // Next month filler days to complete rows (multiple of 7)
    const totalCells = Math.ceil(cells.length / 7) * 7;
    const remaining = totalCells - cells.length;
    for (let i = 1; i <= remaining; i++) {
      cells.push({
        dayNum: i,
        isCurrentMonth: false,
        dateStr: ""
      });
    }
    
    return cells;
  };

  const gridCells = getCalendarGrid();

  const completedInSelectedMonth = completedDates.filter((dStr) => {
    const d = new Date(dStr);
    return d.getFullYear() === calendarDate.year && d.getMonth() === calendarDate.month;
  }).length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 font-sans transition-colors duration-300">
      
      {/* Starting Auth Overlay Portal */}
      {!currentUser && !isGuest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-100/90 dark:bg-slate-950/95 backdrop-blur-md overflow-y-auto px-4 py-8">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col items-center text-center space-y-6">
            
            {/* Logo and Branding header */}
            <div className="flex flex-col items-center gap-2">
              <img 
                src={logoImage} 
                alt="DyanSetu Logo" 
                className="w-16 h-16 object-contain rounded-2xl shadow-md" 
                referrerPolicy="no-referrer"
              />
              <img 
                src={brandTextImage} 
                alt="DyanSetu" 
                className="h-9 object-contain mt-1" 
                referrerPolicy="no-referrer"
              />
              <p className="text-xs text-slate-450 dark:text-slate-500 max-w-xs mt-1">
                Your personalized free 1-on-1 private academic companion
              </p>
            </div>

            {/* Auth Toggle Tab Bar */}
            <div className="flex w-full bg-slate-100 dark:bg-slate-950 p-1 rounded-xl border border-slate-150 dark:border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setAuthMode("login");
                  setAuthError("");
                  setAuthSuccess("");
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                  authMode === "login"
                    ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode("signup");
                  setAuthError("");
                  setAuthSuccess("");
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                  authMode === "signup"
                    ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
                }`}
              >
                Create Account
              </button>
            </div>

            {/* Welcome back / Signup Intro */}
            <div className="space-y-1">
              <h2 className="text-lg md:text-xl font-black text-slate-850 dark:text-white tracking-tight">
                {authMode === "login" ? "Welcome Back, Scholar!" : "Join the Scholar Network!"}
              </h2>
              <p className="text-xs text-slate-450 leading-relaxed max-w-xs">
                {authMode === "login" 
                  ? "Sign in to instantly restore your custom quizzes, private chats, and grade-level study streak."
                  : "Create a free cloud account to save your chapter syllabus coverage and academic milestones automatically."}
              </p>
            </div>

            {/* Primary Form */}
            <form onSubmit={authMode === "login" ? handleLogIn : handleSignUp} className="w-full space-y-3.5 text-left">
              
              {authMode === "signup" && (
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider pl-1">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your name"
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    className="w-full text-xs font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl px-3.5 py-2.5 outline-none text-slate-850 dark:text-white focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider pl-1">Email Address</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-3.5 flex items-center text-slate-400">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    required
                    placeholder="e.g. scholar@dyansetu.com"
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    className="w-full text-xs font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl pl-10 pr-3.5 py-2.5 outline-none text-slate-850 dark:text-white focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider pl-1">Password</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-3.5 flex items-center text-slate-400">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type="password"
                    required
                    placeholder="At least 6 characters"
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    className="w-full text-xs font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl pl-10 pr-3.5 py-2.5 outline-none text-slate-850 dark:text-white focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              {authMode === "signup" && (
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Class Level</label>
                    <select
                      value={profileClass}
                      onChange={(e) => setProfileClass(e.target.value)}
                      className="w-full text-xs font-bold bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl px-2.5 py-2 outline-none text-blue-600 dark:text-blue-400"
                    >
                      {Array.from({ length: 10 }, (_, i) => `Class ${i + 1}`).map((cl) => (
                        <option key={cl} value={cl}>{cl}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Board</label>
                    <select
                      value={profileBoard}
                      onChange={(e) => setProfileBoard(e.target.value)}
                      className="w-full text-xs font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl px-2.5 py-2 outline-none text-slate-850 dark:text-white"
                    >
                      <option value="CBSE">CBSE</option>
                      <option value="ICSE">ICSE</option>
                      <option value="State Board">State Board</option>
                      <option value="IB Syllabus">IB / Cambridge</option>
                    </select>
                  </div>
                </div>
              )}

              {authError && (
                <div className="p-3 text-xs bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 rounded-xl font-semibold leading-relaxed">
                  {authError}
                </div>
              )}

              {authSuccess && (
                <div className="p-3 text-xs bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl font-semibold leading-relaxed">
                  {authSuccess}
                </div>
              )}

              <button
                type="submit"
                disabled={authLoading}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 shadow-md shadow-blue-600/10 cursor-pointer"
              >
                {authLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Processing Secure Connection...</span>
                  </>
                ) : (
                  <span>{authMode === "login" ? "Sign In & Access Account" : "Sign Up & Start Learning"}</span>
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="w-full flex items-center gap-3">
              <hr className="flex-1 border-slate-200 dark:border-slate-800" />
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Or</span>
              <hr className="flex-1 border-slate-200 dark:border-slate-800" />
            </div>

            {/* Google direct sign-up/sign-in button */}
            <div className="w-full">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={authLoading}
                className="w-full bg-white dark:bg-slate-900 text-slate-750 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold text-xs py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                </svg>
                <span>Sign up using Google account direct</span>
              </button>
            </div>

            {/* Continue as Guest */}
            <div className="flex flex-col gap-1">
              <button
                type="button"
                onClick={() => {
                  setIsGuest(true);
                  localStorage.setItem("ds_is_guest", "true");
                }}
                className="text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 underline font-semibold cursor-pointer"
              >
                Continue as Guest (No Cloud Backup)
              </button>
              <p className="text-[9px] text-slate-450 dark:text-slate-500">
                Offline guest progress is saved locally to this browser only.
              </p>
            </div>

          </div>
        </div>
      )}

      {/* Dynamic Embedded YouTube Video Stage if playing */}
      {activeVideo && (
        <div className="bg-slate-900 text-white border-b border-slate-800 py-6 px-4 md:px-8">
          <div className="max-w-4xl mx-auto space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-3 gap-2">
              <div>
                <span className="text-[10px] bg-blue-600/20 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded-md uppercase font-bold tracking-wider">
                  {activeVideo.subject}
                </span>
                <h3 className="text-lg md:text-xl font-extrabold mt-1 tracking-tight">{activeVideo.title}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{activeVideo.chapter} • {activeVideo.durationMins} mins lesson</p>
              </div>

              {/* Mode Selector Tab Bar */}
              <div className="flex bg-slate-950/80 p-1 rounded-xl border border-slate-800 items-center self-start sm:self-center">
                <button
                  onClick={() => setPlayerMode("youtube")}
                  className={`px-3 py-1.5 text-[11px] font-extrabold rounded-lg transition-all flex items-center gap-1.5 ${
                    playerMode === "youtube"
                      ? "bg-blue-600 text-white shadow"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>Standard Video</span>
                </button>
                <button
                  onClick={() => setPlayerMode("interactive")}
                  className={`px-3 py-1.5 text-[11px] font-extrabold rounded-lg transition-all flex items-center gap-1.5 ${
                    playerMode === "interactive"
                      ? "bg-blue-600 text-white shadow"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <Brain className="w-3.5 h-3.5" />
                  <span>Interactive Class</span>
                </button>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <a
                  href={
                    activeVideo.youtubeId.startsWith("PL")
                      ? `https://www.youtube.com/playlist?list=${activeVideo.youtubeId}`
                      : `https://www.youtube.com/watch?v=${activeVideo.youtubeId}`
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-red-600/90 hover:bg-red-600 text-white rounded-xl transition-all font-bold text-xs flex items-center gap-1.5 shadow-sm"
                  title="Open video on YouTube in a new window"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Watch on YT</span>
                </a>

                <button
                  onClick={() => setActiveVideo(null)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all font-bold text-xs flex items-center gap-1.5"
                  title="Close and return"
                >
                  <X className="w-4 h-4" />
                  <span>Close Player</span>
                </button>
              </div>
            </div>
            
            {/* Playable Stage */}
            {playerMode === "youtube" ? (
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black shadow-2xl border border-slate-800">
                <iframe
                  className="absolute inset-0 w-full h-full border-none"
                  src={
                    activeVideo.youtubeId.startsWith("PL")
                      ? `https://www.youtube.com/embed/videoseries?list=${activeVideo.youtubeId}&index=${(activeVideo.playlistIndex || 1) - 1}&autoplay=1`
                      : `https://www.youtube.com/embed/${activeVideo.youtubeId}?autoplay=1&rel=0&modestbranding=1`
                  }
                  title={activeVideo.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            ) : (
              <div className="relative aspect-video w-full rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 shadow-2xl border border-slate-800/80 flex flex-col justify-between p-4 md:p-6">
                {/* Simulated Classroom Screen */}
                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
                    <span className="text-xs font-bold text-blue-400 tracking-wide uppercase">
                      Slide {activeSlideIndex + 1} of {getInteractiveSlides(activeVideo.subject, activeVideo.title).length}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded uppercase">
                      Interactive Tutor Mode
                    </span>
                  </div>

                  <div className="grid md:grid-cols-12 gap-6 items-center flex-1 my-2">
                    {/* Slide Content */}
                    <div className="md:col-span-8 space-y-3">
                      <h4 className="text-base md:text-lg font-extrabold text-white flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                        {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.title}
                      </h4>
                      <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
                        {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.text}
                      </p>
                      
                      {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.points && (
                        <ul className="space-y-1.5 pt-1">
                          {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex].points.map((pt, idx) => (
                            <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                              <span className="text-blue-400 mt-0.5 font-bold">✓</span>
                              <span>{pt}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>

                    {/* Graphic/Animation Panel */}
                    <div className="md:col-span-4 h-32 md:h-full min-h-[120px] bg-slate-950/80 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-center items-center text-center relative overflow-hidden group">
                      <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/5 blur-xl rounded-full"></div>
                      
                      {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.diagramType === "earth" && (
                        <div className="space-y-2">
                          <div className="w-10 h-10 rounded-full border-2 border-dashed border-blue-500 flex items-center justify-center mx-auto animate-[spin_12s_linear_infinite]">
                            <div className="w-6 h-6 rounded-full bg-blue-600"></div>
                          </div>
                          <span className="text-[9px] font-mono text-slate-500 uppercase block">Simulated Earth Rotation</span>
                        </div>
                      )}
                      {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.diagramType === "math" && (
                        <div className="space-y-2">
                          <div className="w-12 h-6 border-2 border-dashed border-amber-500 rounded bg-amber-500/10 mx-auto flex items-center justify-center">
                            <span className="text-[9px] font-mono text-amber-400">3D Block</span>
                          </div>
                          <span className="text-[9px] font-mono text-slate-500 uppercase block">Geometric Layout</span>
                        </div>
                      )}
                      {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.diagramType === "nature" && (
                        <div className="space-y-2">
                          <div className="w-8 h-8 rounded-full bg-emerald-600/20 border border-emerald-500 flex items-center justify-center mx-auto animate-bounce">
                            <span className="text-xs">🌸</span>
                          </div>
                          <span className="text-[9px] font-mono text-slate-500 uppercase block">Nature Choir</span>
                        </div>
                      )}
                      {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.diagramType === "language" && (
                        <div className="space-y-2">
                          <div className="w-10 h-10 border border-slate-800 rounded-lg bg-slate-900 mx-auto flex items-center justify-center text-xs font-bold text-purple-400 font-mono">
                            A-Z
                          </div>
                          <span className="text-[9px] font-mono text-slate-500 uppercase block">Glossary Booster</span>
                        </div>
                      )}
                      {(!getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.diagramType || 
                        getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.diagramType === "science" ||
                        getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.diagramType === "history") && (
                        <div className="space-y-2">
                          <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center mx-auto text-blue-400">
                            <Brain className="w-5 h-5 animate-pulse" />
                          </div>
                          <span className="text-[9px] font-mono text-slate-500 uppercase block">Knowledge Model</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-400 border-t border-slate-800/80 pt-2 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                    <strong>Key Takeaway:</strong> {getInteractiveSlides(activeVideo.subject, activeVideo.title)[activeSlideIndex]?.highlight || "Keep up the excellent work!"}
                  </p>
                </div>

                {/* Slideshow Controller */}
                <div className="flex items-center justify-between border-t border-slate-800/80 pt-4 mt-2">
                  <button
                    disabled={activeSlideIndex === 0}
                    onClick={() => setActiveSlideIndex((prev) => Math.max(0, prev - 1))}
                    className="p-1.5 md:px-3 md:py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 rounded-lg text-xs font-bold text-slate-200 transition-all flex items-center gap-1"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous</span>
                  </button>

                  <div className="flex items-center gap-1">
                    {getInteractiveSlides(activeVideo.subject, activeVideo.title).map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveSlideIndex(idx)}
                        className={`w-2 h-2 rounded-full transition-all ${
                          idx === activeSlideIndex ? "bg-blue-500 w-4" : "bg-slate-700 hover:bg-slate-600"
                        }`}
                        title={`Go to slide ${idx + 1}`}
                      />
                    ))}
                  </div>

                  <button
                    disabled={activeSlideIndex === getInteractiveSlides(activeVideo.subject, activeVideo.title).length - 1}
                    onClick={() => setActiveSlideIndex((prev) => Math.min(getInteractiveSlides(activeVideo.subject, activeVideo.title).length - 1, prev + 1))}
                    className="p-1.5 md:px-3 md:py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-30 disabled:hover:bg-blue-600 rounded-lg text-xs font-bold text-white transition-all flex items-center gap-1"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {playerMode === "youtube" && (
              <div className="bg-slate-950/40 border border-slate-800/80 p-3 rounded-xl flex items-start gap-2.5 text-[11px] text-slate-300">
                <span className="text-blue-400 mt-0.5">ℹ️</span>
                <p className="leading-relaxed">
                  <strong>Notice:</strong> If the YouTube player displays a blank box, it means your browser blocks embedded iframes from loading due to cookie or network restrictions. Click <strong>Watch on YouTube</strong> or toggle <strong>Interactive Class</strong> above to learn inside the app with full content slide decks!
                </p>
              </div>
            )}

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
              <p className="text-xs text-slate-400">
                💡 <span className="font-bold text-slate-200">Study Tip:</span> Take brief notes during this lesson, or ask DyanSetu AI in the chat below to summarize this topic!
              </p>
              <div className="flex gap-2.5 flex-wrap">
                <a
                  href={
                    activeVideo.youtubeId.startsWith("PL")
                      ? `https://www.youtube.com/playlist?list=${activeVideo.youtubeId}&index=${activeVideo.playlistIndex || 1}`
                      : `https://www.youtube.com/watch?v=${activeVideo.youtubeId}`
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-extrabold transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Watch on YouTube</span>
                </a>
                <button
                  onClick={() => handleGenerateAIQuiz(activeVideo.subject, activeVideo.title)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-extrabold transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <Award className="w-3.5 h-3.5" />
                  <span>Test My Understanding</span>
                </button>
                <button
                  onClick={() => handleGenerateRevisionNotes(activeVideo.subject, activeVideo.title)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 rounded-xl text-xs font-extrabold transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Generate Cheat Sheet</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Top Navigation Bar */}
      <nav className="fixed top-0 left-0 lg:left-64 w-full lg:w-[calc(100%-16rem)] z-40 flex justify-between items-center px-4 md:px-8 h-16 bg-transparent dark:bg-transparent border-b border-transparent dark:border-transparent shadow-none">
        <div className="flex items-center gap-4 flex-1">
          {/* Hamburger Menu on Mobile */}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="lg:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
          >
            <Menu className="w-6 h-6" />
          </button>

          {/* Expanded Search Bar */}
          <div className="relative w-full max-w-md hidden md:block">
            <span className="absolute inset-y-0 left-3 flex items-center text-slate-400">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
              className={`w-full bg-slate-100 border-none rounded-xl py-2 pl-9 pr-4 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 transition-all text-sm dark:bg-slate-800 dark:text-slate-100 dark:placeholder-slate-500`}
              placeholder={`Search Class ${profileClass.replace(/\D/g, "")} chapters & topics...`}
            />

            {/* Live Search dropdown overlay */}
            {searchQuery.trim() && isSearchFocused && (
              <div className="absolute top-full left-0 w-full mt-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-50 max-h-80 overflow-y-auto">
                <p className="p-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800">
                  Syllabus Matches
                </p>
                {searchResults.length === 0 ? (
                  <p className="p-4 text-xs text-slate-400 text-center">No matching chapters in {profileClass}.</p>
                ) : (
                  searchResults.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={item.action}
                      className="w-full text-left p-3 hover:bg-slate-50 dark:hover:bg-slate-800 flex flex-col transition-colors border-b border-slate-100 dark:border-slate-800/50"
                    >
                      <span className="text-xs font-semibold text-slate-800 dark:text-slate-100">{item.title}</span>
                      <span className="text-[10px] text-slate-400 mt-0.5">{item.subtitle}</span>
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
        </div>

        {/* Brand logo in nav (Mobile layout) */}
        <div 
          onClick={handleGoToDashboard}
          className="flex lg:hidden items-center gap-2 flex-1 justify-center cursor-pointer hover:opacity-90 transition-opacity"
          title="Go to Dashboard"
        >
          <img 
            src={logoImage} 
            alt="DyanSetu Logo" 
            className="w-7 h-7 object-contain rounded-md" 
            referrerPolicy="no-referrer"
          />
          <img 
            src={brandTextImage} 
            alt="DyanSetu Text Logo" 
            className="h-5 object-contain" 
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Profile and Settings actions */}
        <div className="flex items-center gap-3">
          {/* Quick grade switcher */}
          <div className="flex items-center gap-1.5 bg-slate-150/60 dark:bg-slate-800/80 px-2.5 py-1.5 rounded-xl border border-slate-200/50 dark:border-slate-800">
            <span className="text-[10px] font-bold text-slate-400 hidden sm:inline uppercase tracking-wider">Active:</span>
            <select
              value={profileClass}
              onChange={(e) => handleClassChange(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-blue-600 dark:text-blue-400 focus:outline-none cursor-pointer pr-1"
            >
              {Array.from({ length: 10 }, (_, i) => `Class ${i + 1}`).map((cl) => (
                <option key={cl} value={cl} className="dark:bg-slate-900 text-slate-800 dark:text-slate-100">
                  {cl}
                </option>
              ))}
            </select>
          </div>

          {/* Supabase Cloud Status Pill */}
          <button
            onClick={() => setActiveTab("settings")}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-[10px] font-bold transition-all border border-slate-200/50 dark:border-slate-800 bg-slate-100/60 dark:bg-slate-800/60 cursor-pointer"
            title={sessionToken ? `Connected to Supabase. Last synced: ${lastSyncedTime || "Just now"}` : "Cloud Sync Offline. Click to login."}
          >
            {sessionToken ? (
              <>
                <Cloud className={`w-3.5 h-3.5 text-emerald-500 ${isSyncing ? "animate-pulse" : ""}`} />
                <span className="text-slate-600 dark:text-slate-300 hidden sm:inline">Cloud Saved</span>
              </>
            ) : (
              <>
                <CloudOff className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-400 hidden sm:inline">Cloud Offline</span>
              </>
            )}
          </button>

          {/* Light/Dark mode toggler */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-300"
            title="Toggle theme mode"
          >
            {isDarkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
          </button>

          {/* User Profile Summary */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
            <div
              className="w-9 h-9 rounded-full bg-blue-100 border border-blue-200 overflow-hidden cursor-pointer"
              onClick={() => setActiveTab("settings")}
            >
              <img
                className="w-full h-full object-cover"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBbNXcJUba8ZC1o5dRKxlom6Kctz-eeAnXT1SGHL5bdMLy4-clk4ZkqiAzxYmI52ZcZ06FA7H01yu602ZMjcrUUL7MGTQ9PygIbKS5Za8WivXpShZWVr8k0rQsskDrw3Wah4yjdByq55qtmDPwzEq_EWOoarSsFQ32f9wzY5516hNrEpoZ4nXAuB_AN_x4vQ9QCiiRpAApZn2SV99ga6hb6MEU-3fk22mj7-uTTz9qPPEEt4nJeLISdFoPlb6qOqcDQZ83SaYLHqQI"
                alt="Student Avatar"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </nav>

      {/* SideNavBar Container */}
      <aside
        className={`fixed left-0 top-0 h-full w-64 p-5 flex flex-col gap-6 bg-white border-r border-slate-200/60 dark:bg-slate-900 dark:border-slate-800/80 z-50 transition-transform duration-300 lg:translate-x-0 ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Brand header */}
        <div className="flex items-center justify-between py-2">
          <div 
            onClick={handleGoToDashboard}
            className="flex items-center gap-2.5 cursor-pointer hover:opacity-90 transition-opacity"
            title="Go to Dashboard"
          >
            <img 
              src={logoImage} 
              alt="DyanSetu Logo" 
              className="w-14 h-14 object-contain rounded-xl" 
              referrerPolicy="no-referrer"
            />
            <img 
              src={brandTextImage} 
              alt="DyanSetu" 
              className="h-9 object-contain" 
              referrerPolicy="no-referrer"
            />
          </div>
          {/* Close Sidebar button (Mobile) */}
          <button
            onClick={() => setIsSidebarOpen(false)}
            className="lg:hidden p-1 rounded-md text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Student Profile Summary */}
        <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-2xl border border-slate-150 dark:border-slate-800">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Scholar Profile</p>
          <p className="text-sm font-extrabold text-slate-800 dark:text-white mt-1 leading-tight">{profileName}</p>
          <div className="flex gap-2 items-center mt-1 text-xs text-blue-600 dark:text-blue-400 font-bold">
            <span>{profileClass}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" />
            <span>{profileBoard}</span>
          </div>
        </div>

        {/* Sidebar Nav Links */}
        <div className="flex flex-col gap-1">
          <button
            onClick={handleGoToDashboard}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all text-left ${
              activeTab === "dashboard"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
            }`}
          >
            <LayoutDashboard className="w-4.5 h-4.5" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("subjects");
              setIsSidebarOpen(false);
            }}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all text-left ${
              activeTab === "subjects"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
            }`}
          >
            <BookOpen className="w-4.5 h-4.5" />
            <span>Syllabus Syllabus</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("library");
              setIsSidebarOpen(false);
            }}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all text-left ${
              activeTab === "library"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
            }`}
          >
            <FileText className="w-4.5 h-4.5" />
            <span>Study Library</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("quiz");
              setIsSidebarOpen(false);
            }}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all text-left ${
              activeTab === "quiz"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
            }`}
          >
            <Award className="w-4.5 h-4.5" />
            <span>AI Quiz Zone</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("tutor");
              setIsSidebarOpen(false);
            }}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all text-left ${
              activeTab === "tutor"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
            }`}
          >
            <Brain className="w-4.5 h-4.5" />
            <span>DyanSetu AI Tutor</span>
          </button>
        </div>

        {/* 100% FREE SCHOLAR STATUS CARD (REPLACED PREMIUM/PRO UPGRADE BOX) */}
        <div className="mt-auto bg-gradient-to-br from-emerald-500/10 to-teal-500/5 border border-emerald-500/20 p-4 rounded-2xl flex flex-col gap-2 dark:from-emerald-500/5 dark:to-transparent">
          <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
            <Sparkles className="w-4 h-4 fill-current" />
            <h4 className="font-extrabold text-[10px] uppercase tracking-wider">Unlimited Free Scholar</h4>
          </div>
          <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal">
            Your premium education is 100% free. Enjoy unlimited customized AI study plans, infinite quizzes, and real-time private tutoring.
          </p>
          <div className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] font-extrabold py-1 px-2.5 rounded-lg text-center uppercase tracking-wide">
            ✓ Public Learning License Active
          </div>
        </div>

        {/* Settings & Support footer links */}
        <div className="flex flex-col gap-1 border-t border-slate-100 pt-3 dark:border-slate-800">
          <button
            onClick={() => {
              setActiveTab("settings");
              setIsSidebarOpen(false);
            }}
            className={`flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
              activeTab === "settings"
                ? "bg-slate-100 text-blue-600 dark:bg-slate-800 dark:text-blue-400"
                : "text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-850"
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Settings</span>
          </button>

          <button
            onClick={() => {
              setActiveTab("support");
              setIsSidebarOpen(false);
            }}
            className={`flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
              activeTab === "support"
                ? "bg-slate-100 text-blue-600 dark:bg-slate-800 dark:text-blue-400"
                : "text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-850"
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Support Help</span>
          </button>
        </div>
      </aside>

      {/* Screen Backdrop for Mobile sidebar overlay */}
      {isSidebarOpen && (
        <div
          onClick={() => setIsSidebarOpen(false)}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-45 lg:hidden"
        />
      )}

      {/* Main Content Area */}
      <main className="lg:ml-64 pt-20 px-4 md:px-8 pb-24 lg:pb-12 min-h-screen">
        <div className="max-w-7xl mx-auto">
          
          {/* DASHBOARD TAB VIEW */}
          {activeTab === "dashboard" && (
            <div className="space-y-8 animate-fade-in">
              
              {/* Header section */}
              <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-2 border-b border-slate-150 dark:border-slate-800/80">
                <div>
                  <h2 className="text-2xl md:text-3xl font-black text-slate-850 dark:text-white tracking-tight leading-tight">
                    Welcome back, {profileName}! 👋
                  </h2>
                  <p className="text-sm text-slate-500 dark:text-slate-450 mt-1">
                    You are viewing personalized materials for <span className="font-extrabold text-blue-600 dark:text-blue-400">{profileClass} ({profileBoard} Syllabus)</span>. Complete chapters to hit your goals!
                  </p>
                </div>

                {/* Daily target card with circular ring */}
                <div className="bg-white border border-slate-200/60 p-4 rounded-2xl flex items-center gap-4 shadow-sm dark:bg-slate-900 dark:border-slate-800/80">
                  <div className="relative w-12 h-12">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        className="text-slate-100 dark:text-slate-800 stroke-current"
                        cx="50"
                        cy="50"
                        fill="transparent"
                        r="40"
                        strokeWidth="8"
                      />
                      <circle
                        className="text-emerald-500 dark:text-emerald-400 stroke-current progress-ring-circle"
                        cx="50"
                        cy="50"
                        fill="transparent"
                        r="40"
                        strokeLinecap="round"
                        strokeWidth="8"
                        style={{
                          strokeDasharray: "251.2",
                          strokeDashoffset: `${251.2 - (251.2 * getAggregateProgress()) / 100}`,
                        }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400">{getAggregateProgress()}%</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-[9px] font-extrabold uppercase tracking-widest text-slate-450">Active Progress</p>
                    <p className="font-extrabold text-sm text-slate-800 dark:text-white leading-tight">
                      Syllabus complete
                    </p>
                  </div>
                </div>
              </header>

              {/* Grid content */}
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
                
                {/* LEFT SIDE: Primary Lectures & Subjects */}
                <div className="xl:col-span-8 space-y-8">
                  
                  {/* Curated Syllabus Chapters with Direct Youtube Links */}
                  <section className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-base md:text-lg font-black text-slate-850 dark:text-white tracking-tight">
                        Recommended Video Lessons
                      </h3>
                      <button
                        onClick={() => setActiveTab("subjects")}
                        className="text-xs font-bold text-blue-600 hover:underline dark:text-blue-400"
                      >
                        Browse Syllabus
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {subjects.slice(0, 2).map((sub) => {
                        // Pick a key chapter with YouTube video link
                        const showcaseChapter = sub.chapters[sub.chapters.length - 1] || sub.chapters[0];
                        if (!showcaseChapter) return null;
                        return (
                          <div
                            key={sub.id}
                            className="bg-white rounded-2xl overflow-hidden border border-slate-200/50 shadow-sm hover:shadow-md transition-all dark:bg-slate-900 dark:border-slate-800/60"
                          >
                            <div
                              className="relative h-44 group cursor-pointer bg-slate-950 flex items-center justify-center"
                              onClick={() => handleLaunchVideo(showcaseChapter.title, sub.name, showcaseChapter.unit, showcaseChapter.youtubeId, showcaseChapter.durationMins, showcaseChapter.playlistIndex)}
                            >
                              <img
                                className="w-full h-full object-cover opacity-80 group-hover:opacity-65 transition-all"
                                src={
                                  showcaseChapter.youtubeId.startsWith("PL")
                                    ? "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&q=80"
                                    : `https://img.youtube.com/vi/${showcaseChapter.youtubeId}/hqdefault.jpg`
                                }
                                alt={showcaseChapter.title}
                                referrerPolicy="no-referrer"
                              />
                              {/* Overlay Play Button */}
                              <div className="absolute inset-0 flex items-center justify-center">
                                <div className="w-11 h-11 bg-white rounded-full flex items-center justify-center text-blue-600 shadow-xl group-hover:scale-110 transition-transform">
                                  <Play className="w-5 h-5 fill-current pl-0.5" />
                                </div>
                              </div>
                              <span className="absolute bottom-2.5 right-2.5 bg-slate-950/85 text-white text-[10px] px-2 py-0.5 rounded font-extrabold font-mono">
                                {showcaseChapter.durationMins} MINS
                              </span>
                            </div>

                            <div className="p-4 space-y-2">
                              <div className="flex justify-between items-center">
                                <span className={`px-2 py-0.5 ${sub.colorClass} text-[10px] font-extrabold rounded-md uppercase tracking-wider`}>
                                  {sub.name}
                                </span>
                                <span className="text-[10px] font-bold text-slate-400">
                                  {showcaseChapter.unit}
                                </span>
                              </div>
                              <h4
                                className="font-extrabold text-slate-850 dark:text-white text-sm line-clamp-1 hover:text-blue-600 transition-colors cursor-pointer"
                                onClick={() => handleLaunchVideo(showcaseChapter.title, sub.name, showcaseChapter.unit, showcaseChapter.youtubeId, showcaseChapter.durationMins, showcaseChapter.playlistIndex)}
                              >
                                {showcaseChapter.title}
                              </h4>
                              <p className="text-xs text-slate-400">
                                Click to watch this interactive class lesson.
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </section>

                  {/* Your Subjects Section */}
                  <section className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-base md:text-lg font-black text-slate-850 dark:text-white tracking-tight">
                        Your Personalized Subjects
                      </h3>
                      <span className="text-xs font-bold text-slate-400">Curriculum for {profileClass}</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {subjects.map((sub) => (
                        <div
                          key={sub.id}
                          onClick={() => {
                            setSelectedSubject(sub);
                            setActiveTab("subjects");
                          }}
                          className="subject-card group flex flex-col p-5 bg-white border border-slate-200/60 rounded-2xl transition-all cursor-pointer dark:bg-slate-900 dark:border-slate-800/80 hover:border-blue-500/30"
                        >
                          <div className="flex justify-between items-start">
                            <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${sub.colorClass}`}>
                              {renderSubjectIcon(sub.icon, "w-6 h-6")}
                            </div>
                            <span className="text-xs font-black text-slate-400">{sub.chapters.length} Units</span>
                          </div>
                          
                          <h4 className="font-extrabold text-sm text-slate-800 dark:text-white leading-tight mt-4 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                            {sub.name}
                          </h4>
                          <p className="text-[11px] text-slate-400 dark:text-slate-500 line-clamp-2 mt-1">
                            {sub.description}
                          </p>

                          {/* Progress bar */}
                          <div className="w-full bg-slate-100 dark:bg-slate-800 h-1 rounded-full mt-4 overflow-hidden">
                            <div
                              className="bg-blue-600 h-full transition-all duration-500"
                              style={{ width: `${sub.progressPercent}%` }}
                            />
                          </div>
                          <div className="flex justify-between items-center mt-2">
                            <span className="text-[9px] font-black text-slate-400 uppercase">
                              PROGRESS
                            </span>
                            <span className="text-[10px] font-black text-blue-600 dark:text-blue-400">
                              {sub.progressPercent}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </section>
                </div>

                {/* RIGHT SIDE: AI Recommendations & Progress Streaks */}
                <div className="xl:col-span-4 space-y-8">
                  
                  {/* AI RECOMMENDED SECTION */}
                  <section className="bg-blue-50 dark:bg-blue-950/20 p-6 rounded-[24px] border border-blue-100 dark:border-blue-900/30 relative overflow-hidden flex flex-col gap-4 shadow-sm">
                    <div className="relative z-10 flex flex-col gap-3.5">
                      <div className="flex items-center gap-2">
                        <div className="bg-blue-600 p-1 rounded-lg text-white">
                          <Sparkles className="w-3.5 h-3.5 fill-current" />
                        </div>
                        <h3 className="font-black text-[10px] text-blue-600 uppercase tracking-widest leading-none dark:text-blue-400">
                          AI Smart Recommendation
                        </h3>
                      </div>

                      <div>
                        <h4 className="text-base font-black text-slate-850 dark:text-white leading-tight">
                          Need to quickly revise for {profileClass}?
                        </h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-normal">
                          DyanSetu AI dynamically recommends a rapid revision note and diagnostic quiz based on your active syllabus:
                        </p>
                      </div>

                      {/* Interactive Recommend Options */}
                      <div className="space-y-2.5">
                        <div
                          onClick={() => {
                            const sub = subjects[0] || { name: "General Science" };
                            handleGenerateAIQuiz(sub.name, "Key conceptual structures");
                          }}
                          className="bg-white/80 border border-slate-100 p-3 rounded-xl flex items-center gap-3 backdrop-blur-sm cursor-pointer hover:bg-white transition-all shadow-sm group dark:bg-slate-900/75 dark:border-slate-800/80"
                        >
                          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center group-hover:rotate-6 transition-transform dark:bg-blue-900/50 dark:text-blue-400">
                            <Award className="w-4.5 h-4.5" />
                          </div>
                          <div className="flex-1">
                            <p className="text-[11px] font-extrabold text-slate-800 dark:text-white">Conceptual Quiz</p>
                            <p className="text-[9px] text-slate-400">Interactive testing (5 Questions)</p>
                          </div>
                          <ChevronRight className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 group-hover:translate-x-0.5 transition-transform" />
                        </div>

                        <div
                          onClick={() => {
                            const sub = subjects[0] || { name: "General Science" };
                            handleGenerateRevisionNotes(sub.name, "Comprehensive Formula Guide");
                          }}
                          className="bg-white/80 border border-slate-100 p-3 rounded-xl flex items-center gap-3 backdrop-blur-sm cursor-pointer hover:bg-white transition-all shadow-sm group dark:bg-slate-900/75 dark:border-slate-800/80"
                        >
                          <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center group-hover:rotate-6 transition-transform dark:bg-emerald-900/50 dark:text-emerald-400">
                            <FileText className="w-4.5 h-4.5" />
                          </div>
                          <div className="flex-1">
                            <p className="text-[11px] font-extrabold text-slate-800 dark:text-white">Study Cheat Sheet</p>
                            <p className="text-[9px] text-slate-400">Generate neat revision outlines</p>
                          </div>
                          <ChevronRight className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 group-hover:translate-x-0.5 transition-transform" />
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setActiveTab("tutor");
                          setTutorMessages((prev) => [
                            ...prev,
                            {
                              id: `msg-act-${Date.now()}`,
                              role: "user",
                              text: `Please give me a high-level syllabus summary of ${profileClass} Mathematics.`,
                              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                            },
                          ]);
                          handleSendTutorMessage(`Please give me a high-level syllabus summary of ${profileClass} Mathematics.`);
                        }}
                        className="w-full mt-1.5 py-2.5 bg-blue-600 text-white font-extrabold rounded-xl shadow-md shadow-blue-500/10 hover:bg-blue-500 active:scale-95 transition-all text-xs cursor-pointer text-center"
                      >
                        Start Learning Session
                      </button>
                    </div>
                  </section>

                  {/* LEARNING STREAK PROGRESS */}
                  <section className="bg-white border border-slate-200/60 p-5 rounded-[24px] dark:bg-slate-900 dark:border-slate-800/80 shadow-sm space-y-4">
                    <div>
                      <h3 className="font-extrabold text-[10px] text-slate-400 uppercase tracking-widest mb-3">Your Progress Streak</h3>
                      
                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-1 text-orange-500 font-extrabold">
                            <Bolt className="w-5 h-5 fill-current animate-pulse" />
                            <span className="text-xl font-black">12 Days</span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5">Active Study streak</p>
                        </div>
                        <div className="w-10 h-10 bg-orange-500/10 rounded-xl flex items-center justify-center text-orange-500">
                          <Trophy className="w-5 h-5" />
                        </div>
                      </div>

                      <div className="flex justify-between gap-1">
                        {["M", "T", "W", "T", "F", "S", "S"].map((day, idx) => (
                          <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                            <span className="text-[10px] font-bold text-slate-400">{day}</span>
                            <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                              idx < 5 
                                ? "bg-emerald-500 text-white" 
                                : idx === 5 
                                ? "bg-blue-600 text-white" 
                                : "bg-slate-100 dark:bg-slate-800 text-slate-400"
                            }`}>
                              {idx < 6 ? "✓" : ""}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Divider */}
                    <div className="border-t border-slate-150 dark:border-slate-800/80 pt-4" />

                    {/* MONTHLY CALENDAR TRACKER */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">
                            Monthly Log
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <button
                            onClick={handlePrevMonth}
                            className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-colors"
                            title="Previous Month"
                          >
                            <ChevronLeft className="w-4 h-4" />
                          </button>
                          <span className="text-xs font-bold text-slate-700 dark:text-slate-200 min-w-[85px] text-center">
                            {MONTH_NAMES[calendarDate.month]} {calendarDate.year}
                          </span>
                          <button
                            onClick={handleNextMonth}
                            className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-colors"
                            title="Next Month"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Calendar Weekday Labels */}
                      <div className="grid grid-cols-7 gap-1 text-center">
                        {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => (
                          <span key={i} className="text-[9px] font-bold text-slate-400 uppercase">
                            {day}
                          </span>
                        ))}
                      </div>

                      {/* Calendar Grid Days with Transition */}
                      <div className="relative overflow-hidden min-h-[150px]">
                        <AnimatePresence mode="wait">
                          <motion.div
                            key={`${calendarDate.year}-${calendarDate.month}`}
                            initial={{ opacity: 0, x: 10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: -10 }}
                            transition={{ duration: 0.15 }}
                            className="grid grid-cols-7 gap-1"
                          >
                            {gridCells.map((cell, idx) => {
                              const isCompleted = cell.isCurrentMonth && cell.dateStr && completedDates.includes(cell.dateStr);
                              const isToday = cell.isCurrentMonth && cell.dateStr === new Date().toISOString().split("T")[0];
                              
                              return (
                                <div
                                  key={idx}
                                  className={`aspect-square flex flex-col items-center justify-center rounded-lg text-[10px] font-bold transition-all relative ${
                                    !cell.isCurrentMonth
                                      ? "text-slate-300 dark:text-slate-700 bg-transparent pointer-events-none"
                                      : isCompleted
                                      ? "bg-emerald-500 text-white shadow-sm shadow-emerald-500/25"
                                      : isToday
                                      ? "bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-500/30"
                                      : "text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/40 hover:bg-slate-100 dark:hover:bg-slate-800"
                                  }`}
                                  title={cell.isCurrentMonth && cell.dateStr ? `Date: ${cell.dateStr}${isCompleted ? " (Completed)" : ""}` : undefined}
                                >
                                  <span>{cell.dayNum}</span>
                                  {isCompleted && (
                                    <span className="absolute bottom-0.5 w-1 h-1 rounded-full bg-white opacity-80" />
                                  )}
                                  {!isCompleted && isToday && (
                                    <span className="absolute bottom-0.5 w-1 h-1 rounded-full bg-blue-500 animate-pulse" />
                                  )}
                                </div>
                              );
                            })}
                          </motion.div>
                        </AnimatePresence>
                      </div>

                      {/* Summary Banner */}
                      <div className="bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800/80 rounded-xl p-2.5 text-[10px] text-slate-500 dark:text-slate-400 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <Trophy className="w-3.5 h-3.5 text-emerald-500" />
                          <span>
                            Completed on: <strong className="text-slate-700 dark:text-slate-200">{completedInSelectedMonth} days</strong>
                          </span>
                        </div>
                        {completedInSelectedMonth > 0 && (
                          <span className="text-emerald-600 dark:text-emerald-400 font-extrabold uppercase tracking-wide text-[8px]">
                            Good job!
                          </span>
                        )}
                      </div>
                    </div>
                  </section>
                </div>

              </div>
            </div>
          )}

          {/* SUBJECTS & SYLLABUS TAB VIEW */}
          {activeTab === "subjects" && (
            <div className="space-y-6 animate-fade-in">
              <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-150 dark:border-slate-800">
                <div>
                  <h2 className="text-xl md:text-2xl font-black text-slate-850 dark:text-white tracking-tight">
                    Syllabus Chapters
                  </h2>
                  <p className="text-xs text-slate-450 mt-0.5">
                    Browse and complete chapters. Select any chapter to watch its high-quality YouTube lecture instantly.
                  </p>
                </div>
                
                {/* Back button if active subject selected */}
                {selectedSubject && (
                  <button
                    onClick={() => setSelectedSubject(null)}
                    className="self-start sm:self-auto px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>View All Subjects</span>
                  </button>
                )}
              </header>

              {!selectedSubject ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {subjects.map((sub) => (
                    <div
                      key={sub.id}
                      className="bg-white border border-slate-200/60 p-5 rounded-2xl shadow-sm dark:bg-slate-900 dark:border-slate-800/80 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex justify-between items-center">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${sub.colorClass}`}>
                            {renderSubjectIcon(sub.icon, "w-5 h-5")}
                          </div>
                          <span className="text-xs font-bold text-blue-600 dark:text-blue-400">{sub.progressPercent}% Complete</span>
                        </div>
                        <h3 className="font-extrabold text-base mt-3 text-slate-800 dark:text-white">{sub.name}</h3>
                        <p className="text-xs text-slate-400 mt-1 leading-normal">{sub.description}</p>
                        
                        {/* Preview list of chapters */}
                        <div className="mt-4 space-y-2 border-t border-slate-100 dark:border-slate-800/60 pt-3">
                          {sub.chapters.slice(0, 3).map((chap) => (
                            <div key={chap.id} className="flex justify-between items-center text-xs">
                              <span className="text-slate-500 dark:text-slate-400 line-clamp-1">{chap.title}</span>
                              <span className="text-[10px] font-bold text-slate-400">{chap.unit}</span>
                            </div>
                          ))}
                          {sub.chapters.length > 3 && (
                            <p className="text-[10px] text-blue-500 font-extrabold uppercase mt-1">
                              + {sub.chapters.length - 3} more chapters
                            </p>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => setSelectedSubject(sub)}
                        className="w-full mt-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-600 dark:bg-blue-950/40 dark:hover:bg-blue-900/50 dark:text-blue-400 text-xs font-extrabold rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <span>Open Complete Syllabus</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  {/* Detailed chapter list */}
                  <div className="lg:col-span-7 space-y-4">
                    <div className="bg-white border border-slate-200/60 p-5 rounded-2xl dark:bg-slate-900 dark:border-slate-800/80 shadow-sm">
                      <div className="flex gap-3 items-center">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${selectedSubject.colorClass}`}>
                          {renderSubjectIcon(selectedSubject.icon, "w-5 h-5")}
                        </div>
                        <div>
                          <h3 className="font-extrabold text-base text-slate-850 dark:text-white">{selectedSubject.name}</h3>
                          <p className="text-xs text-slate-400">{profileClass} Syllabus Coursework</p>
                        </div>
                      </div>

                      <div className="mt-6 space-y-3">
                        {selectedSubject.chapters.map((chap) => (
                          <div
                            key={chap.id}
                            className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition-colors ${
                              chap.completed 
                                ? "bg-emerald-500/5 border-emerald-500/20" 
                                : "bg-slate-50 border-slate-150 hover:border-slate-300 dark:bg-slate-950/40 dark:border-slate-800"
                            }`}
                          >
                            <div className="flex items-center gap-3 flex-1 min-w-0">
                              <button
                                onClick={() => handleToggleChapter(selectedSubject.id, chap.id)}
                                className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                                  chap.completed 
                                    ? "bg-emerald-500 border-emerald-600 text-white" 
                                    : "border-slate-300 hover:border-blue-500 dark:border-slate-700"
                                }`}
                              >
                                {chap.completed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                              </button>

                              <div className="min-w-0">
                                <p className={`text-xs font-bold leading-tight ${chap.completed ? "text-emerald-700 dark:text-emerald-400 line-through" : "text-slate-800 dark:text-white"}`}>
                                  {chap.title}
                                </p>
                                <p className="text-[10px] text-slate-450 mt-0.5">{chap.unit} • {chap.durationMins} mins</p>
                              </div>
                            </div>

                            <button
                              onClick={() => handleLaunchVideo(chap.title, selectedSubject.name, chap.unit, chap.youtubeId, chap.durationMins, chap.playlistIndex)}
                              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[10px] font-extrabold uppercase tracking-wider flex items-center gap-1.5 active:scale-95 transition-all"
                            >
                              <Play className="w-3 h-3 fill-current" />
                              <span>Watch Video</span>
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* AI Tutor controls for active subject */}
                  <div className="lg:col-span-5 space-y-4">
                    <div className="bg-blue-50/60 border border-blue-100 p-5 rounded-2xl dark:bg-blue-950/15 dark:border-blue-900/30 flex flex-col gap-4">
                      <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                        <Brain className="w-5 h-5" />
                        <h4 className="font-extrabold text-xs uppercase tracking-wider">AI Interactive Sandbox</h4>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                        Ready to study this subject? Our AI-powered study sandbox can instantly generate customized revision notes or curriculum check quizzes for you.
                      </p>

                      <div className="flex flex-col gap-2">
                        <button
                          onClick={() => handleGenerateAIQuiz(selectedSubject.name, "Interactive Syllabus Review")}
                          className="w-full py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-500 active:scale-95 transition-all flex items-center justify-center gap-1.5"
                        >
                          <Award className="w-4 h-4" />
                          <span>Generate Topic Quiz</span>
                        </button>

                        <button
                          onClick={() => handleGenerateRevisionNotes(selectedSubject.name, "Quick revision outline")}
                          className="w-full py-2.5 bg-slate-900 dark:bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-800 dark:hover:bg-slate-750 active:scale-95 transition-all flex items-center justify-center gap-1.5"
                        >
                          <FileText className="w-4 h-4" />
                          <span>Compile AI Cheat Sheet</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STUDY LIBRARY TAB VIEW */}
          {activeTab === "library" && (
            <div className="space-y-6 animate-fade-in">
              <header className="pb-4 border-b border-slate-150 dark:border-slate-800">
                <h2 className="text-xl md:text-2xl font-black text-slate-850 dark:text-white tracking-tight">
                  My Study Library
                </h2>
                <p className="text-xs text-slate-450 mt-0.5">
                  Your repository of generated custom revision cheat sheets, study notes, and formulas.
                </p>
              </header>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Note list column */}
                <div className="lg:col-span-4 space-y-4">
                  <div className="bg-white border border-slate-200/60 p-4 rounded-2xl dark:bg-slate-900 dark:border-slate-800 shadow-sm">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Saved Cheat Sheets</p>
                    
                    {savedNotes.length === 0 ? (
                      <div className="text-center py-6 text-xs text-slate-400">
                        No saved cheat sheets yet. Click "Generate Cheat Sheet" on a video or chapter to make one.
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {savedNotes.map((note) => (
                          <div
                            key={note.id}
                            onClick={() => setGeneratedNotes({
                              topic: note.topic,
                              subject: note.subject,
                              markdown: note.notesMarkdown,
                            })}
                            className={`p-3 rounded-xl border cursor-pointer text-left transition-all ${
                              generatedNotes?.topic === note.topic
                                ? "bg-blue-50 border-blue-200 dark:bg-blue-950/40 dark:border-blue-900"
                                : "bg-slate-50 hover:bg-slate-100 border-slate-150 dark:bg-slate-950/40 dark:border-slate-850"
                            }`}
                          >
                            <span className="text-[9px] font-extrabold uppercase tracking-wider bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded">
                              {note.subject}
                            </span>
                            <h4 className="font-extrabold text-xs text-slate-800 dark:text-white mt-1.5 line-clamp-1">{note.topic}</h4>
                            <p className="text-[10px] text-slate-450 mt-0.5">Generated {note.createdAt}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Dynamic generation panel */}
                  <div className="bg-slate-100 dark:bg-slate-900 border border-slate-200/60 p-5 rounded-2xl shadow-sm space-y-4">
                    <div className="flex items-center gap-2 text-slate-850 dark:text-white">
                      <Sparkles className="w-4 h-4 text-blue-600" />
                      <h4 className="font-extrabold text-xs uppercase tracking-wider">Dynamic Note Generator</h4>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Subject</label>
                        <select
                          value={quizSubject}
                          onChange={(e) => setQuizSubject(e.target.value)}
                          className="w-full text-xs font-semibold bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 outline-none"
                        >
                          {subjects.map((sub) => (
                            <option key={sub.id} value={sub.name}>{sub.name}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Topic or Keyword</label>
                        <input
                          type="text"
                          value={quizTopic}
                          onChange={(e) => setQuizTopic(e.target.value)}
                          placeholder="e.g. Gravity, Polynomials, Fractions..."
                          className="w-full text-xs bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 outline-none text-slate-800 dark:text-white"
                        />
                      </div>

                      <button
                        onClick={() => handleGenerateRevisionNotes(quizSubject, quizTopic || "Important Syllabus formulas")}
                        disabled={notesLoading}
                        className="w-full py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-500 disabled:opacity-50 transition-all flex items-center justify-center gap-1"
                      >
                        {notesLoading ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>Compiling with AI...</span>
                          </>
                        ) : (
                          <>
                            <Brain className="w-3.5 h-3.5" />
                            <span>Create Study Note</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Display active note column */}
                <div className="lg:col-span-8">
                  {notesLoading ? (
                    <div className="bg-white border border-slate-200 p-8 rounded-2xl dark:bg-slate-900 dark:border-slate-800 flex flex-col items-center justify-center text-center py-20 gap-4 shadow-sm">
                      <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center animate-bounce">
                        <Sparkles className="w-6 h-6 text-blue-600 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-800 dark:text-white text-base">Generating Study Note</h4>
                        <p className="text-xs text-slate-400 mt-1">DyanSetu AI is curating, formatting, and structures high-contrast Markdown revision lists.</p>
                      </div>
                    </div>
                  ) : notesError ? (
                    <div className="bg-red-50/50 border border-red-200 p-6 rounded-2xl dark:bg-red-950/10 dark:border-red-900/30 text-red-700 text-xs">
                      {notesError}
                    </div>
                  ) : generatedNotes ? (
                    <div className="bg-white border border-slate-200/60 p-6 md:p-8 rounded-2xl dark:bg-slate-900 dark:border-slate-800 shadow-sm space-y-4">
                      <div className="flex justify-between items-start border-b border-slate-100 dark:border-slate-800/85 pb-4">
                        <div>
                          <span className="text-[10px] bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-900/40 px-2 py-0.5 rounded font-extrabold uppercase">
                            {generatedNotes.subject}
                          </span>
                          <h3 className="text-xl font-black text-slate-900 dark:text-white mt-1.5">{generatedNotes.topic}</h3>
                        </div>
                        <button
                          onClick={() => {
                            // Copy to clipboard
                            navigator.clipboard.writeText(generatedNotes.markdown);
                            alert("Notes Markdown copied successfully!");
                          }}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg text-[10px] font-bold"
                        >
                          Copy Markdown
                        </button>
                      </div>

                      <div className="prose dark:prose-invert max-w-none text-left">
                        {renderMarkdown(generatedNotes.markdown)}
                      </div>
                    </div>
                  ) : (
                    <div className="bg-white border border-slate-200/60 p-8 rounded-2xl dark:bg-slate-900 dark:border-slate-800 flex flex-col items-center justify-center text-center py-20 text-slate-400 shadow-sm">
                      <FileText className="w-12 h-12 stroke-[1.5] text-slate-300 mb-3" />
                      <h4 className="font-bold text-sm text-slate-750 dark:text-slate-300">No Note Selected</h4>
                      <p className="text-xs max-w-xs mt-1 leading-normal">
                        Select an existing cheat sheet from the sidebar list, or insert a custom topic keyword to draft dynamic outlines instantly.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* AI QUIZ ZONE TAB VIEW */}
          {activeTab === "quiz" && (
            <div className="space-y-6 animate-fade-in">
              <header className="pb-4 border-b border-slate-150 dark:border-slate-800">
                <h2 className="text-xl md:text-2xl font-black text-slate-850 dark:text-white tracking-tight">
                  AI Quiz Zone
                </h2>
                <p className="text-xs text-slate-450 mt-0.5">
                  Generate instant 5-question multi-choice worksheets calibrated for {profileClass} syllabus to identify gaps in your study knowledge.
                </p>
              </header>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Selector Column */}
                <div className="lg:col-span-4 space-y-4">
                  <div className="bg-white border border-slate-200/60 p-5 rounded-2xl dark:bg-slate-900 dark:border-slate-800 shadow-sm space-y-4">
                    <div className="flex items-center gap-2 text-slate-850 dark:text-white">
                      <Sparkles className="w-4 h-4 text-blue-600" />
                      <h4 className="font-extrabold text-xs uppercase tracking-wider">Dynamic Quiz Builder</h4>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Subject Area</label>
                        <select
                          value={quizSubject}
                          onChange={(e) => setQuizSubject(e.target.value)}
                          className="w-full text-xs font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 outline-none text-slate-800 dark:text-white"
                        >
                          {subjects.map((sub) => (
                            <option key={sub.id} value={sub.name}>{sub.name}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Target Topic</label>
                        <input
                          type="text"
                          value={quizTopic}
                          onChange={(e) => setQuizTopic(e.target.value)}
                          placeholder="e.g. Rational Numbers, Laws of Motion..."
                          className="w-full text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 outline-none text-slate-850 dark:text-white"
                        />
                      </div>

                      <button
                        onClick={() => handleGenerateAIQuiz(quizSubject, quizTopic || "Comprehensive Chapter Practice")}
                        disabled={quizLoading}
                        className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all disabled:opacity-55 flex items-center justify-center gap-1.5"
                      >
                        {quizLoading ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>Building Worksheet...</span>
                          </>
                        ) : (
                          <>
                            <Award className="w-3.5 h-3.5" />
                            <span>Generate Quiz</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* History List */}
                  <div className="bg-white border border-slate-200/60 p-5 rounded-2xl dark:bg-slate-900 dark:border-slate-800 shadow-sm">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Recent Performance</p>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {quizHistory.map((hist) => (
                        <div key={hist.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs">
                          <div>
                            <h5 className="font-extrabold text-slate-850 dark:text-white line-clamp-1">{hist.quizTitle}</h5>
                            <p className="text-[10px] text-slate-400 mt-0.5">{hist.subject} • {new Date(hist.date).toLocaleDateString()}</p>
                          </div>
                          <span className={`px-2 py-0.5 rounded font-extrabold ${
                            hist.score >= hist.totalQuestions - 1 
                              ? "bg-emerald-500/10 text-emerald-600" 
                              : "bg-blue-500/10 text-blue-600"
                          }`}>
                            {hist.score}/{hist.totalQuestions}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Main Quiz Area Column */}
                <div className="lg:col-span-8">
                  {quizLoading ? (
                    <div className="bg-white border border-slate-200 p-8 rounded-2xl dark:bg-slate-900 dark:border-slate-800 flex flex-col items-center justify-center text-center py-24 gap-4 shadow-sm">
                      <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center animate-bounce">
                        <Award className="w-6 h-6 text-blue-600 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-800 dark:text-white text-base">Creating Curated Quiz Worksheet</h4>
                        <p className="text-xs text-slate-400 mt-1">DyanSetu AI is drafting custom Class-calibrated diagnostic queries, options, and rich explanations...</p>
                      </div>
                    </div>
                  ) : quizError ? (
                    <div className="bg-red-50/50 border border-red-200 p-6 rounded-2xl text-red-700 text-xs dark:bg-red-950/10 dark:border-red-900/30">
                      {quizError}
                    </div>
                  ) : activeQuiz ? (
                    <div className="bg-white border border-slate-200/60 p-6 md:p-8 rounded-2xl dark:bg-slate-900 dark:border-slate-800 shadow-sm space-y-6">
                      
                      {/* Score final results */}
                      {quizState.showFinalResults ? (
                        <div className="text-center py-10 space-y-5">
                          <div className="w-16 h-16 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto text-2xl font-black">
                            🎉
                          </div>
                          <div className="space-y-1">
                            <h3 className="text-xl font-black text-slate-850 dark:text-white">Quiz Completed Successfully!</h3>
                            <p className="text-xs text-slate-400">Great effort! You completed the worksheet for {activeQuiz.title}.</p>
                          </div>

                          <div className="bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 p-6 rounded-2xl max-w-xs mx-auto text-center">
                            <p className="text-xs font-bold text-slate-400 uppercase">Your Diagnostic Score</p>
                            <p className="text-4xl font-black text-blue-600 dark:text-blue-400 mt-2">{quizState.score} <span className="text-lg font-normal text-slate-400">/ {activeQuiz.questions.length}</span></p>
                            <p className="text-xs text-slate-500 mt-2">
                              {quizState.score === activeQuiz.questions.length 
                                ? "Perfect score! Outstanding grasp of topics." 
                                : quizState.score >= activeQuiz.questions.length - 2 
                                ? "Great comprehension! Watch lessons to fill any remaining gaps." 
                                : "Keep studying! Try watching the related video lectures."}
                            </p>
                          </div>

                          <div className="flex gap-3 justify-center">
                            <button
                              onClick={() => {
                                handleGenerateAIQuiz(activeQuiz.subject, "Alternative Curation");
                              }}
                              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition-all"
                            >
                              Try Another Quiz
                            </button>
                            <button
                              onClick={() => {
                                setActiveQuiz(null);
                              }}
                              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition-all"
                            >
                              Exit Quiz Area
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          {/* Progress indicators */}
                          <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-850 pb-3">
                            <div>
                              <span className="text-[10px] bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 font-extrabold px-1.5 py-0.5 rounded uppercase">
                                {activeQuiz.subject}
                              </span>
                              <h4 className="font-extrabold text-sm text-slate-850 dark:text-white mt-1">{activeQuiz.title}</h4>
                            </div>
                            <span className="text-xs font-bold text-slate-400">
                              Question {quizState.currentIndex + 1} of {activeQuiz.questions.length}
                            </span>
                          </div>

                          {/* Render current question */}
                          {(() => {
                            const currentQuestion = activeQuiz.questions[quizState.currentIndex];
                            return (
                              <div className="space-y-5">
                                <p className="font-extrabold text-slate-850 dark:text-white text-base">
                                  {currentQuestion.question}
                                </p>

                                <div className="grid grid-cols-1 gap-3">
                                  {currentQuestion.options.map((option, idx) => {
                                    // Highlight scheme based on submission state
                                    let btnStyles = "bg-slate-50 border-slate-200 hover:bg-slate-100 dark:bg-slate-950/30 dark:border-slate-800";
                                    if (quizState.selectedOption === idx) {
                                      btnStyles = "bg-blue-50 border-blue-400 dark:bg-blue-950/40 dark:border-blue-900 ring-2 ring-blue-500/20";
                                    }
                                    if (quizState.isSubmitted) {
                                      if (idx === currentQuestion.correctOptionIndex) {
                                        btnStyles = "bg-emerald-50 border-emerald-400 dark:bg-emerald-950/30 dark:border-emerald-900 text-emerald-800 dark:text-emerald-400 ring-2 ring-emerald-500/20";
                                      } else if (quizState.selectedOption === idx) {
                                        btnStyles = "bg-red-50 border-red-300 dark:bg-red-950/20 dark:border-red-900 text-red-800 dark:text-red-400 ring-2 ring-red-500/10";
                                      } else {
                                        btnStyles = "opacity-55 bg-slate-50 border-slate-200 dark:bg-slate-950/30 dark:border-slate-800";
                                      }
                                    }

                                    return (
                                      <button
                                        key={idx}
                                        onClick={() => handleQuizOptionSelect(idx)}
                                        disabled={quizState.isSubmitted}
                                        className={`w-full p-4 rounded-xl border text-left text-xs font-extrabold flex gap-3 transition-all ${btnStyles}`}
                                      >
                                        <span className="w-5 h-5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center font-bold text-[10px]">
                                          {String.fromCharCode(65 + idx)}
                                        </span>
                                        <span className="flex-1">{option}</span>
                                      </button>
                                    );
                                  })}
                                </div>

                                {/* Explanation section once answer submitted */}
                                {quizState.isSubmitted && (
                                  <div className="p-4 bg-blue-50/60 dark:bg-blue-950/15 border border-blue-100 dark:border-blue-900/40 rounded-xl space-y-1 text-xs">
                                    <p className="font-black text-blue-600 dark:text-blue-400 uppercase tracking-wider text-[10px]">
                                      {quizState.selectedOption === currentQuestion.correctOptionIndex ? "✓ Correct Answer!" : "✗ Concept Trap Identified!"}
                                    </p>
                                    <p className="text-slate-600 dark:text-slate-300 leading-normal">
                                      {currentQuestion.explanation}
                                    </p>
                                  </div>
                                )}

                                {/* Action Buttons */}
                                <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-850">
                                  {!quizState.isSubmitted ? (
                                    <button
                                      onClick={handleQuizSubmitAnswer}
                                      disabled={quizState.selectedOption === null}
                                      className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl uppercase tracking-wider transition-all"
                                    >
                                      Check Answer
                                    </button>
                                  ) : (
                                    <button
                                      onClick={handleQuizNextQuestion}
                                      className="px-5 py-2.5 bg-slate-900 dark:bg-slate-800 text-white font-extrabold text-xs rounded-xl uppercase tracking-wider transition-all flex items-center gap-1.5"
                                    >
                                      <span>{quizState.currentIndex < activeQuiz.questions.length - 1 ? "Next Question" : "View Results"}</span>
                                      <ChevronRight className="w-4 h-4" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="bg-white border border-slate-200/60 p-8 rounded-2xl dark:bg-slate-900 dark:border-slate-800 flex flex-col items-center justify-center text-center py-24 text-slate-400 shadow-sm">
                      <Award className="w-12 h-12 stroke-[1.5] text-slate-300 mb-3" />
                      <h4 className="font-bold text-sm text-slate-750 dark:text-slate-300">Worksheet Sandbox Blank</h4>
                      <p className="text-xs max-w-xs mt-1 leading-normal">
                        Choose a study topic in the sidebar generator, or take diagnostic evaluations to analyze class mastery dynamically.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* DYAN AI TUTOR TAB VIEW */}
          {activeTab === "tutor" && (
            <div className="space-y-6 animate-fade-in h-[calc(100vh-140px)] flex flex-col justify-between">
              
              <header className="pb-3 border-b border-slate-150 dark:border-slate-800 flex justify-between items-center">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <h2 className="text-lg md:text-xl font-black text-slate-850 dark:text-white tracking-tight">
                      DyanSetu AI Study Companion
                    </h2>
                  </div>
                  <p className="text-xs text-slate-450 mt-0.5">
                    Your personal 1-on-1 private tutor for CBSE Class {profileClass.replace(/\D/g, "")}. Ask questions or clear homework queries instantly!
                  </p>
                </div>
                <button
                  onClick={() => {
                    if (confirm("Reset tutor discussion log?")) {
                      const initial = [
                        {
                          id: "msg-1",
                          role: "model",
                          text: `Hi ${profileName}! 👋 I'm DyanSetu AI, your personalized tutor for **${profileClass}**. How can I help you conquer your coursework or explain tricky homework topics today?`,
                          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                        },
                      ];
                      setTutorMessages(initial);
                    }
                  }}
                  className="px-2.5 py-1 text-[10px] font-bold text-slate-400 hover:text-slate-600 uppercase border border-slate-200 dark:border-slate-800 rounded-lg"
                >
                  Reset Log
                </button>
              </header>

              {/* Chat Bubble scroll viewport */}
              <div className="flex-1 overflow-y-auto bg-white border border-slate-200/60 dark:bg-slate-900 dark:border-slate-800 rounded-2xl p-4 md:p-6 space-y-4 no-scrollbar">
                {tutorMessages.map((msg) => {
                  const isUser = msg.role === "user";
                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-3.5 max-w-2xl ${isUser ? "ml-auto flex-row-reverse text-right" : "mr-auto text-left"}`}
                    >
                      {/* Avatar icon badge */}
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm ${
                        isUser 
                          ? "bg-blue-100 text-blue-600 dark:bg-blue-900/50" 
                          : "bg-gradient-to-br from-blue-600 to-indigo-600 text-white"
                      }`}>
                        {isUser ? "AS" : <Brain className="w-4 h-4" />}
                      </div>

                      {/* Content block */}
                      <div className="space-y-1">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">
                          {isUser ? profileName : "DyanSetu AI Tutor"}
                        </p>
                        <div className={`p-4 rounded-2xl text-xs md:text-sm leading-relaxed space-y-2 ${
                          isUser 
                            ? "bg-blue-600 text-white shadow-sm rounded-tr-none" 
                            : "bg-slate-50 border border-slate-150 text-slate-800 dark:bg-slate-950/40 dark:border-slate-850 dark:text-slate-200 rounded-tl-none"
                        }`}>
                          {isUser ? (
                            <p>{msg.text}</p>
                          ) : (
                            <div className="prose dark:prose-invert max-w-none text-left">
                              {renderMarkdown(msg.text)}
                            </div>
                          )}
                        </div>
                        <span className="text-[9px] text-slate-400 block px-1">{msg.timestamp}</span>
                      </div>
                    </div>
                  );
                })}

                {chatLoading && (
                  <div className="flex gap-3.5 mr-auto">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white flex items-center justify-center">
                      <Brain className="w-4 h-4 animate-spin" />
                    </div>
                    <div className="space-y-1 text-left">
                      <p className="text-[10px] font-bold text-slate-400 uppercase">DyanSetu AI is thinking</p>
                      <div className="p-3 bg-slate-50 dark:bg-slate-950/30 rounded-xl rounded-tl-none flex gap-1.5 items-center">
                        <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                        <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                        <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "300ms" }} />
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={mainChatEndRef} />
              </div>

              {/* Chat Input form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendTutorMessage(chatInput);
                }}
                className="flex gap-3 bg-white border border-slate-200/60 dark:bg-slate-900 dark:border-slate-800 p-2.5 rounded-2xl shadow-sm"
              >
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder={`Ask DyanSetu AI about Class ${profileClass.replace(/\D/g, "")} topics (e.g. 'explain Rational Numbers with an analogy')`}
                  className="flex-1 bg-transparent border-none text-xs md:text-sm px-3 focus:outline-none dark:text-slate-100"
                />
                <button
                  type="submit"
                  disabled={!chatInput.trim() || chatLoading}
                  className="p-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all disabled:opacity-50 flex items-center gap-1 text-xs uppercase tracking-wider"
                >
                  <Send className="w-4 h-4" />
                  <span className="hidden sm:inline">Ask AI</span>
                </button>
              </form>
            </div>
          )}

          {/* SETTINGS TAB VIEW */}
          {activeTab === "settings" && (
            <div className="bg-white border border-slate-200/60 p-6 md:p-8 rounded-2xl dark:bg-slate-900 dark:border-slate-800 shadow-sm space-y-8 animate-fade-in">
              <header className="pb-4 border-b border-slate-150 dark:border-slate-800">
                <h2 className="text-xl md:text-2xl font-black text-slate-850 dark:text-white tracking-tight">
                  Scholar Configuration
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Update your school grade level (Class 1 to Class 10), state board, and profile details to customize your curriculum dynamically.
                </p>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Profile attributes form */}
                <div className="space-y-5">
                  <h3 className="font-extrabold text-sm text-slate-800 dark:text-white">General Information</h3>
                  
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Full Name</label>
                    <input
                      type="text"
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full text-xs font-semibold bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl px-3 py-2.5 outline-none text-slate-850 dark:text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Active Study Class</label>
                      <select
                        value={profileClass}
                        onChange={(e) => handleClassChange(e.target.value)}
                        className="w-full text-xs font-bold bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl px-3 py-2.5 outline-none text-blue-600 dark:text-blue-400"
                      >
                        {Array.from({ length: 10 }, (_, i) => `Class ${i + 1}`).map((cl) => (
                          <option key={cl} value={cl}>{cl}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Education Board</label>
                      <select
                        value={profileBoard}
                        onChange={(e) => setProfileBoard(e.target.value)}
                        className="w-full text-xs font-bold bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl px-3 py-2.5 outline-none text-slate-850 dark:text-white"
                      >
                        <option value="CBSE">CBSE</option>
                        <option value="ICSE">ICSE</option>
                        <option value="State Board">State Board</option>
                        <option value="IB Syllabus">IB / Cambridge</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Firebase Integration Account & Cloud Sync Panel */}
                <div className="space-y-5 bg-slate-50/70 dark:bg-slate-950/20 p-5 rounded-2xl border border-slate-150 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <h3 className="font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
                      <Database className="w-4 h-4 text-emerald-500" />
                      <span>Firebase Cloud Backup</span>
                    </h3>
                    {currentUser ? (
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        Connected
                      </span>
                    ) : (
                      <span className="text-[10px] bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500 font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CloudOff className="w-3 h-3" />
                        Offline Mode
                      </span>
                    )}
                  </div>

                  {currentUser ? (
                    /* Logged In View */
                    <div className="space-y-4">
                      <div className="space-y-2 text-xs">
                        <div className="flex justify-between border-b border-slate-100 dark:border-slate-800/80 pb-2">
                          <span className="text-slate-400 flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> Email Account:</span>
                          <span className="font-bold text-slate-700 dark:text-slate-300">{currentUser.email}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-100 dark:border-slate-800/80 pb-2">
                          <span className="text-slate-400 flex items-center gap-1"><RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin text-blue-500" : ""}`} /> Sync Mode:</span>
                          <span className="font-bold text-emerald-600 dark:text-emerald-400">Automatic / Real-time</span>
                        </div>
                        {lastSyncedTime && (
                          <div className="flex justify-between border-b border-slate-100 dark:border-slate-800/80 pb-2">
                            <span className="text-slate-400">Last Cloud Saved:</span>
                            <span className="font-bold text-slate-500 dark:text-slate-400">{lastSyncedTime}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={syncWithFirebase}
                          disabled={isSyncing}
                          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm disabled:opacity-50 cursor-pointer"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
                          <span>{isSyncing ? "Syncing..." : "Sync Now"}</span>
                        </button>

                        <button
                          onClick={handleLogOut}
                          className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs py-2 px-3 rounded-xl transition-all cursor-pointer"
                        >
                          Sign Out
                        </button>
                      </div>

                      {authSuccess && (
                        <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">{authSuccess}</p>
                      )}
                    </div>
                  ) : (
                    /* Logged Out View - Sign In / Sign Up form */
                    <div className="space-y-3.5">
                      <p className="text-[11px] text-slate-400 leading-normal">
                        Save your active study streak, class syllabus coverage, completed chapters, and practice quiz history automatically to Firebase Cloud so you never lose progress.
                      </p>

                      <form onSubmit={authMode === "login" ? handleLogIn : handleSignUp} className="space-y-3">
                        <div className="space-y-1">
                          <div className="relative">
                            <span className="absolute inset-y-0 left-3 flex items-center text-slate-400">
                              <Mail className="w-3.5 h-3.5" />
                            </span>
                            <input
                              type="email"
                              required
                              placeholder="Student Email (e.g., student@school.com)"
                              value={authEmail}
                              onChange={(e) => setAuthEmail(e.target.value)}
                              className="w-full text-xs font-semibold bg-white dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 outline-none text-slate-800 dark:text-white placeholder-slate-450 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <div className="relative">
                            <span className="absolute inset-y-0 left-3 flex items-center text-slate-400">
                              <Lock className="w-3.5 h-3.5" />
                            </span>
                            <input
                              type="password"
                              required
                              placeholder="Secure Password"
                              value={authPassword}
                              onChange={(e) => setAuthPassword(e.target.value)}
                              className="w-full text-xs font-semibold bg-white dark:bg-slate-950 border border-slate-150 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 outline-none text-slate-800 dark:text-white placeholder-slate-450 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                            />
                          </div>
                        </div>

                        {authError && (
                          <div className="p-2 text-[10px] bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 rounded-lg font-semibold leading-relaxed">
                            {authError}
                          </div>
                        )}

                        {authSuccess && (
                          <div className="p-2 text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-lg font-semibold leading-relaxed">
                            {authSuccess}
                          </div>
                        )}

                        <button
                          type="submit"
                          disabled={authLoading}
                          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2 px-4 rounded-xl transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 shadow-sm shadow-blue-600/10 cursor-pointer"
                        >
                          {authLoading ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              <span>Connecting...</span>
                            </>
                          ) : (
                            <span>{authMode === "login" ? "Sign In & Restore Progress" : "Create Account & Sync Progress"}</span>
                          )}
                        </button>
                      </form>

                      {/* Google Button inside Settings Tab */}
                      <div className="pt-1">
                        <button
                          type="button"
                          onClick={handleGoogleSignIn}
                          disabled={authLoading}
                          className="w-full bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold text-xs py-2 px-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                        >
                          <svg className="w-4 h-4" viewBox="0 0 24 24">
                            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                          </svg>
                          <span>Sign in with Google</span>
                        </button>
                      </div>

                      <div className="text-center pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setAuthMode(authMode === "login" ? "signup" : "login");
                            setAuthError("");
                            setAuthSuccess("");
                          }}
                          className="text-[10px] text-blue-600 dark:text-blue-400 hover:underline font-bold uppercase tracking-wider cursor-pointer"
                        >
                          {authMode === "login" ? "New Scholar? Create a free Account" : "Already registered? Sign In"}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* SUPPORT HELP TAB VIEW */}
          {activeTab === "support" && (
            <div className="bg-white border border-slate-200/60 p-6 md:p-8 rounded-2xl dark:bg-slate-900 dark:border-slate-800 shadow-sm space-y-6 animate-fade-in text-left">
              <header className="pb-4 border-b border-slate-150 dark:border-slate-800">
                <h2 className="text-xl md:text-2xl font-black text-slate-850 dark:text-white tracking-tight">
                  Support & Syllabus Help
                </h2>
                <p className="text-xs text-slate-450 mt-0.5">
                  Frequently asked questions, study strategy manuals, and workspace assistance.
                </p>
              </header>

              <div className="space-y-4 max-w-3xl">
                <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-150 dark:border-slate-800 rounded-xl">
                  <h4 className="font-extrabold text-sm text-slate-800 dark:text-white">How do I study a specific chapter syllabus?</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    Head to the **Syllabus Syllabus** tab in the sidebar. Select your active grade, choose a subject, and click **"Watch Video"** on any chapter. This launches the playable YouTube interactive lecture. 
                  </p>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-150 dark:border-slate-800 rounded-xl">
                  <h4 className="font-extrabold text-sm text-slate-800 dark:text-white">Can I switch my class levels?</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    Yes! You can instantly switch your grade from **Class 1 to Class 10** using the active Grade Switcher dropdown in the top navigation bar. DyanSetu immediately customizes your available subjects, study notes library, and practice questions for that class.
                  </p>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-150 dark:border-slate-800 rounded-xl">
                  <h4 className="font-extrabold text-sm text-slate-800 dark:text-white">Are all features absolutely free?</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    Yes, absolutely! The premium subscription walls have been completely removed. Every student has full free access to customized AI quizzes, private interactive study chat-bots, and complete dynamic grade curriculums.
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>
      </main>

    </div>
  );
}
