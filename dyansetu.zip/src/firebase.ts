import { initializeApp } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User,
} from "firebase/auth";
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  collection,
  query,
  where,
  getDocs,
  addDoc,
  deleteDoc,
} from "firebase/firestore";
import firebaseConfig from "../firebase-applet-config.json";

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize Firebase Auth
export const auth = getAuth(app);

// Initialize Google Auth Provider
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: "select_account",
});

// Initialize Firestore Database
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Helper interface for study tracking
export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  class: string;
  board: string;
  createdAt: string;
  updatedAt: string;
}

// User-authored content models matching firebase-blueprint
export interface DbSavedNote {
  id: string;
  userId: string;
  topic: string;
  subject: string;
  notesMarkdown: string;
  createdAt: string;
}

export interface DbQuizHistory {
  id: string;
  userId: string;
  quizTitle: string;
  subject: string;
  score: number;
  totalQuestions: number;
  date: string;
}

export interface DbCompletedChapter {
  id: string;
  userId: string;
  chapterId: string;
  completed: boolean;
  completedAt: string;
}

export {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
};
export type { User };
