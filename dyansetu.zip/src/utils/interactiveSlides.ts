export interface Slide {
  title: string;
  text: string;
  diagramType?: "earth" | "math" | "nature" | "history" | "science" | "language";
  highlight?: string;
  points?: string[];
}

export function getInteractiveSlides(subject: string, chapterTitle: string): Slide[] {
  const normalizedTitle = chapterTitle.toLowerCase();
  const normalizedSubject = subject.toLowerCase();

  // English: Wake Up!
  if (normalizedTitle.includes("wake up")) {
    return [
      {
        title: "Welcome to 'Wake Up!'",
        text: "Let's explore C.F. Alexander's beautiful poem that celebrates the joy, beauty, and energy of early mornings! Waking up early connects us with the wonders of nature.",
        diagramType: "nature",
        highlight: "The morning is full of life and positive energy!",
        points: [
          "Observe how the birds sing and the sun shines.",
          "Morning air is fresh and boosts your physical energy.",
          "Early risers have more time to learn, play, and grow."
        ]
      },
      {
        title: "Nature's Morning Choir",
        text: "The birds are singing in the trees, and you can hear the buzzing of the little bees. Waking up early lets us hear this wonderful, quiet music of nature.",
        diagramType: "nature",
        highlight: "Hear the quiet melodies of nature!",
        points: [
          "Chirping birds communicate with each other.",
          "Honeybees begin their collection of sweet nectar early.",
          "The morning breeze makes the tree leaves rustle softly."
        ]
      },
      {
        title: "Poem Vocabulary & Meaning",
        text: "Let's learn new words from the poem to build our language and storytelling skills:",
        diagramType: "language",
        highlight: "Expand your English vocabulary!",
        points: [
          "Lovely: Very beautiful, pleasing, and wonderful.",
          "Buzzing: The low, continuous humming sound made by flying bees.",
          "Sleepyhead: A playful name for a person who is sleepy or lazy."
        ]
      },
      {
        title: "Interactive Morning Challenge",
        text: "Which of these animals wake up early in the morning? Almost all of them! Let's name them:",
        diagramType: "science",
        highlight: "The morning animals are active!",
        points: [
          "Cows, Horses, Ducks, and Sheep graze in the fresh morning dew.",
          "The tiny, chirpy Chicken is among the earliest to call.",
          "Birds fly high looking for insects and seeds."
        ]
      }
    ];
  }

  // English: Neha's Alarm Clock
  if (normalizedTitle.includes("neha's alarm")) {
    return [
      {
        title: "Neha's Morning Wish",
        text: "Neha hates her alarm clock! It rings at 6:00 AM every single morning and pulls her out of her cozy, warm bed. She wishes it would forget its job.",
        diagramType: "language",
        highlight: "The struggle to wake up early!",
        points: [
          "Neha loves her cozy blankets and morning sleep.",
          "The alarm clock represents duty and waking up on time.",
          "Neha wonders why everything must happen by the clock."
        ]
      },
      {
        title: "The Persistent Helpers",
        text: "Even when the alarm clock breaks, Neha cannot sleep forever! Other elements of nature wake her up: first the chirping little birds, and then the warm, bright Sun.",
        diagramType: "nature",
        highlight: "Nature has its own morning calls!",
        points: [
          "Chirpy birds land on her window sill to wake her up.",
          "The warm Sun fills her room with soft, bright light.",
          "Even without technology, nature keeps us on track!"
        ]
      },
      {
        title: "Our Inner Body Clock",
        text: "Why do we wake up, eat, and sleep at the exact same time every day? Neha's mother explains that there is a clock inside our very bodies!",
        diagramType: "science",
        highlight: "You have an internal body clock!",
        points: [
          "The hypothalamus in your brain acts as your master clock.",
          "It regulates when you feel hungry, sleepy, or active.",
          "Sticking to a daily routine keeps this inner clock perfectly happy!"
        ]
      }
    ];
  }

  // Maths: Building with Bricks
  if (normalizedTitle.includes("building with bricks") || normalizedTitle.includes("bricks")) {
    return [
      {
        title: "Brick Patterns of Murshidabad",
        text: "Welcome to 'Building with Bricks'! Historically, builders in Bengal created gorgeous, symmetrical brick floor patterns. Bricks are standard building blocks of world history.",
        diagramType: "math",
        highlight: "Math is found in architecture and geometry!",
        points: [
          "Bricks are placed in alternating styles to create strength.",
          "Repeating geometrical patterns form beautiful visual arts.",
          "Standard bricks have flat, regular surfaces for stacking."
        ]
      },
      {
        title: "Anatomy of a Brick (3D Shape)",
        text: "A brick is a 3-dimensional geometric shape known as a cuboid (or rectangular prism). Let's examine its dimensions:",
        diagramType: "math",
        highlight: "A brick has 6 faces, 12 edges, and 8 corners!",
        points: [
          "Faces: It has 6 flat faces. Every face of a brick is a rectangle.",
          "Edges: It has 12 straight lines where two faces meet.",
          "Corners (Vertices): It has 8 sharp points where three edges meet."
        ]
      },
      {
        title: "Brick Arches and Jali Windows",
        text: "Ancient builders didn't just stack bricks in flat walls. They used clever engineering to create arches and beautiful open Jali (net-like) windows that let in light and cool breeze.",
        diagramType: "math",
        highlight: "Curves can be built from straight bricks!",
        points: [
          "Arches distribute weight downward and outward, making them extremely strong.",
          "Jali patterns are formed by leaving precise spaces between bricks.",
          "These designs are used in mosques, temples, and palaces."
        ]
      },
      {
        title: "Math Calculation Challenge",
        text: "Let's put our math skills to work! Suppose a local kiln sells bricks at the rate of ₹2,000 for 1,000 bricks:",
        diagramType: "math",
        highlight: "Can you solve this unitary method problem?",
        points: [
          "If 1,000 bricks cost ₹2,000, then 1 brick costs ₹2 (₹2,000 / 1,000).",
          "How much will 3,000 bricks cost? 3,000 x ₹2 = ₹6,000!",
          "Unitary method helps us calculate prices for any quantity."
        ]
      }
    ];
  }

  // Maths: Long and Short
  if (normalizedTitle.includes("long and short") || normalizedTitle.includes("length")) {
    return [
      {
        title: "Units of Measurement",
        text: "How do we measure how long or short something is? We use different metric units based on the size of the object we are measuring!",
        diagramType: "math",
        highlight: "Millimeters, Centimeters, Meters, and Kilometers!",
        points: [
          "Millimeter (mm): For extremely tiny things (like a pencil lead).",
          "Centimeter (cm): For medium household items (like a ruler or a book).",
          "Meter (m): For large objects (like room heights or playground lengths).",
          "Kilometer (km): For long geographical distances between cities."
        ]
      },
      {
        title: "Metric Conversion Formulas",
        text: "To switch between metric units, we use easy multiplication or division factors of 10, 100, and 1,000. Let's memorize these:",
        diagramType: "math",
        highlight: "10 mm = 1 cm | 100 cm = 1 m | 1,000 m = 1 km",
        points: [
          "To convert Meters to Centimeters, multiply by 100 (e.g., 5 m = 500 cm).",
          "To convert Kilometers to Meters, multiply by 1,000 (e.g., 3 km = 3,000 m).",
          "To convert Centimeters to Meters, divide by 100."
        ]
      },
      {
        title: "Fun Distance Challenge",
        text: "Let's solve a real-life distance problem: Neha ran in a school race of 1,500 meters. How many kilometers and meters did she run?",
        diagramType: "math",
        highlight: "Split the meters into kilometers!",
        points: [
          "We know that 1,000 meters makes exactly 1 kilometer.",
          "So, 1,500 meters can be split into 1,000 meters + 500 meters.",
          "This equals exactly 1 Kilometer and 500 Meters (or 1.5 km)!"
        ]
      }
    ];
  }

  // Science: Going to School
  if (normalizedTitle.includes("going to school") || normalizedTitle.includes("school")) {
    return [
      {
        title: "Bamboo Bridges of Assam",
        text: "In Assam, it rains heavily during the monsoon. Water fills up everywhere. But children don't miss school! They build temporary bamboo bridges to cross flooded areas.",
        diagramType: "science",
        highlight: "Bridges made of bamboo and ropes!",
        points: [
          "They hold their books in one hand and walk steadily across the bamboo.",
          "Ropes are tied to steady trees to act as safety handrails.",
          "Bamboo is incredibly strong, flexible, and abundant in Assam."
        ]
      },
      {
        title: "The Ladakh Trolley",
        text: "In mountainous Ladakh, wide and deep rivers flow between steep cliffs. Children cross the river using a trolley: an open wooden cart hanging on a strong iron wire rope.",
        diagramType: "science",
        highlight: "Crossing valleys in a wooden trolley!",
        points: [
          "A pulley helps the trolley slide across the strong iron rope.",
          "Four or five children sit comfortably inside the trolley together.",
          "It relies on gravity and pulling to cross the river in minutes."
        ]
      },
      {
        title: "Camel Carts & Bullock Carts",
        text: "Children in the deserts of Rajasthan ride Camel Carts across miles of hot, sandy dunes. In flat rural plains, children ride Bullock Carts through green, lush crop fields.",
        diagramType: "science",
        highlight: "Animal-driven transport across India!",
        points: [
          "Camels have padded feet that do not sink into loose desert sand.",
          "Bullock carts travel slowly, allowing children to enjoy the scenery.",
          "During rain or heavy sun, children use umbrellas for shade."
        ]
      },
      {
        title: "Learning is Unstoppable",
        text: "No matter if it is snow in the Himalayas, thick forests of Central India, or rocky paths of Uttarakhand, children walk miles with joy just to learn and meet friends!",
        diagramType: "nature",
        highlight: "Education is a beautiful, unstoppable journey!",
        points: [
          "Walking together in groups helps children stay safe and confident.",
          "Difficult terrains build resilience and courage in students.",
          "Going to school is a fundamental right of every child."
        ]
      }
    ];
  }

  // Science: Ear to Ear
  if (normalizedTitle.includes("ear to ear") || normalizedTitle.includes("ears")) {
    return [
      {
        title: "Who has Got My Ears?",
        text: "Different animals have different types of ears! Some ears are large and fan-like, while others are tiny and completely hidden. Let's study how animals hear.",
        diagramType: "science",
        highlight: "Ears come in amazing sizes and shapes!",
        points: [
          "Elephants have massive, fan-like ears to hear distant sounds and cool themselves.",
          "Rabbits have long ears on top of their head to detect predators.",
          "Dogs can rotate their ears to locate the exact direction of noises."
        ]
      },
      {
        title: "Hidden Ears (Birds & Reptiles)",
        text: "Can you see a bird's ears? No! Birds, frogs, snakes, and lizards don't have visible external ears. Instead, they have tiny, feather-covered holes on their heads.",
        diagramType: "nature",
        highlight: "Hearing without external ear lobes!",
        points: [
          "Birds have tiny pinholes on both sides of their head, covered by protective feathers.",
          "Lizards and crocodiles also have tiny holes that act as ears.",
          "Snakes do not have ears at all! They feel vibrations on the ground."
        ]
      },
      {
        title: "Skins, Fur, and Animal Patterns",
        text: "Did you know that an animal's skin patterns are caused by hair or fur on their skin? If an animal had no hair, it would have no colored patterns!",
        diagramType: "science",
        highlight: "Fur, feathers, and scales protect animals!",
        points: [
          "Tigers and Zebras have beautiful stripes that help them camouflage.",
          "Animals with hair on skin and visible ears give birth to young ones (Mammals).",
          "Animals with feathers/scales and hidden ears lay eggs (Aves, Reptiles)."
        ]
      }
    ];
  }

  // Geography: Our Earth
  if (normalizedTitle.includes("our earth") || normalizedTitle.includes("earth")) {
    return [
      {
        title: "The Earth: Our Cosmic Home",
        text: "The Earth is the third planet from the Sun and the only celestial body known to harbor life. It is nicknamed the 'Blue Planet' because of its vast water oceans.",
        diagramType: "earth",
        highlight: "Over 70% of the Earth is covered with water!",
        points: [
          "Earth's unique atmosphere contains oxygen and protects us from rays.",
          "Liquid water is crucial for all plants, animals, and human life.",
          "The Earth is a spherical shape, slightly flattened at the poles."
        ]
      },
      {
        title: "Earth's Rotation: Day & Night",
        text: "The Earth spins on its imaginary axis like a giant top from West to East. This spinning movement is called Rotation. It takes 24 hours to complete one rotation.",
        diagramType: "earth",
        highlight: "Rotation causes our daily Day and Night cycles!",
        points: [
          "The side of Earth facing the Sun experiences bright Day.",
          "The side facing away from the Sun experiences dark Night.",
          "This constant spinning gives us our 24-hour day cycle."
        ]
      },
      {
        title: "Earth's Revolution & Seasons",
        text: "While spinning, the Earth also travels in an oval-shaped orbit around the Sun. This movement is called Revolution. It takes 365 and 1/4 days (one year) to complete.",
        diagramType: "earth",
        highlight: "Revolution and axis tilt cause the Changing Seasons!",
        points: [
          "The tilt of the Earth's axis is 23.5 degrees.",
          "When a hemisphere tilts toward the Sun, it experiences Summer.",
          "When a hemisphere tilts away from the Sun, it experiences Winter."
        ]
      }
    ];
  }

  // History: Our Past I / Indus Valley
  if (normalizedTitle.includes("our past") || normalizedTitle.includes("history")) {
    return [
      {
        title: "What is History?",
        text: "History is the systematic study of human activities, societies, and civilizations in the past. It helps us understand how our modern world was built.",
        diagramType: "history",
        highlight: "History is a detective story of human life!",
        points: [
          "Chronology: We arrange historical events in the exact order of time.",
          "BC/AD: Before Christ and Anno Domini (or BCE/CE) help us count years.",
          "Learning history prevents us from repeating past societal mistakes."
        ]
      },
      {
        title: "The Sources of History",
        text: "How do historians know what happened thousands of years ago? They study clues called 'sources' left behind by our ancestors:",
        diagramType: "history",
        highlight: "Archaeological and Literary clues!",
        points: [
          "Archaeological: Ruins of buildings, pottery, coins, tools, and monuments.",
          "Inscriptions: Words carved on hard surfaces like rocks, pillars, or copper plates.",
          "Manuscripts: Hand-written books on palm leaves or bark of birch trees."
        ]
      }
    ];
  }

  // Generic fallback slide set for any other chapter
  return [
    {
      title: `Welcome to ${chapterTitle}`,
      text: `Let's dive into this interactive class lesson for ${chapterTitle}. Studying this topic will expand your knowledge, analytical thinking, and academic confidence!`,
      diagramType: "science",
      highlight: "A great day to learn something new!",
      points: [
        "Read each slide carefully to understand core concepts.",
        "Take brief notes to boost long-term memory retention.",
        "Prepare for the understanding quiz after this review!"
      ]
    },
    {
      title: "Core Concepts & Key Highlights",
      text: "Every great topic has foundation principles. Let's look at the core terms and essential logic of this lesson:",
      diagramType: "math",
      highlight: "Focus on understanding, not just memorizing!",
      points: [
        "Key terms are definitions that scientists and scholars use.",
        "Concepts explain the hidden 'Why' behind our natural and social world.",
        "Formulas, timelines, or rules structure this knowledge cleanly."
      ]
    },
    {
      title: "Self-Review Summary",
      text: "You have reviewed the key components! Winding up, let's look at the big picture and why this topic matters to our daily lives.",
      diagramType: "language",
      highlight: "Knowledge is power when applied!",
      points: [
        "Every subject connects directly to how we live, communicate, and build.",
        "Discuss what you learned with parents or friends to test your memory.",
        "Click 'Test My Understanding' to challenge yourself on this chapter!"
      ]
    }
  ];
}
